﻿using UnityEngine;
using System.Collections;

public class _2DxFX : MonoBehaviour
{

    public static bool ActiveShadow = true;

}
