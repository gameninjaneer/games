using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class BurgarRop : MonoBehaviour
    {
        public Rigidbody2D Burgar;
        public virtual void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("Player"))
            {
                this.transform.parent.GetComponent<Animator>().Play("FallRop", -1, 0);
                if (this.Burgar != null)
                {
                    this.Burgar.isKinematic = false;
                }
            }
        }
    }
}