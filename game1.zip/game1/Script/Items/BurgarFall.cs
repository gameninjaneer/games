using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class BurgarFall : MonoBehaviour
    {
        public virtual void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("Player"))
            {
                this.transform.parent.GetComponent<Animator>().Play("FallRop", -1, 0);
            }
        }
    }
}