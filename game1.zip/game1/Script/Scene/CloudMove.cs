using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class CloudMove : MonoBehaviour
    {
        public float Speed;
        public float MinX;
        public virtual void Update()
        {
            this.transform.Translate((Vector3.right * this.Speed) * Time.deltaTime);
            if (this.transform.position.x < this.MinX)
            {
                UnityEngine.Object.Destroy(this.gameObject);
            }
        }

        public CloudMove()
        {
            this.Speed = 1f;
        }
    }
}