using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class BackHome : MonoBehaviour
    {
        private SpriteRenderer S;
        public virtual void Start()
        {
            this.S = this.GetComponent<SpriteRenderer>();
            if (GameManager.Night)
            {
                this.SetNight();
            }
        }

        public virtual void SetNight()
        {
            if (this.GetComponent<Renderer>().isVisible == false)
            {

                {
                    float _173 = 0f;
                    Color _174 = this.S.color;
                    _174.a = _173;
                    this.S.color = _174;
                }
            }
        }

        public virtual void SetDay()
        {
            if (this.GetComponent<Renderer>().isVisible == false)
            {

                {
                    float _175 = 0.9f;
                    Color _176 = this.S.color;
                    _176.a = _175;
                    this.S.color = _176;
                }
            }
        }
    }
}