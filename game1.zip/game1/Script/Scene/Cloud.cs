using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class Cloud : MonoBehaviour
    {
        public SpriteRenderer S;
        public bool Up;
        public virtual void Start() //SetColor();
        {
        }
    }
}//}