using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class Beton : MonoBehaviour
    {
        public virtual void OnCollisionEnter2D(Collision2D other) //GameManager.Enerji -= 100;
        {
            if (other.collider.tag == "Player")
            {
                Vector2 contactPoint = other.contacts[0].point;
                Vector3 center = this.GetComponent<Collider2D>().bounds.center;
                bool top = contactPoint.y > center.y;
                if (other.contacts[0].point.y > (this.transform.position.y + (this.transform.lossyScale.y / 2)))
                {
                    other.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(4.7f, 6.5f);
                }
                else
                {
                }
            }
        }
    }
}