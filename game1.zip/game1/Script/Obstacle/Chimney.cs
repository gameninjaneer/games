using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class Chimney : MonoBehaviour
    {
        public GameObject[] Smoke;
        public Transform SmokePoint;
        public float SmokeTimeRange;
        public float FirstWait;
        private Animator animator;
        public virtual void Start()
        {
            this.InvokeRepeating("ShootSmoke", this.FirstWait, this.SmokeTimeRange);
            this.animator = (Animator)this.GetComponent(typeof(Animator));
        }

        public virtual void ShootSmoke()
        {
            this.animator.Play("Shoot", -1, 0);
            UnityEngine.Object.Instantiate(Smoke[Random.Range(0, 3)], SmokePoint.position + new Vector3(0, 0.3f, 0), Quaternion.identity);
        }

        public Chimney()
        {
            this.SmokeTimeRange = 2f;
            this.FirstWait = 1f;
        }
    }
}