using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class TNT : MonoBehaviour
    {
        private AudioManager AudioManager;
        private FxManager FxManager;
        public virtual void Start()
        {
            this.FxManager = (FxManager)GameObject.FindWithTag("FxManager").GetComponent("FxManager");
            this.AudioManager = (AudioManager)GameObject.FindWithTag("Audio").GetComponent("AudioManager");
        }

        public virtual void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("KillTrigger"))
            {
                this.GetComponent<Collider2D>().enabled = false;
                this.FxManager.TNTExplod(this.transform.position);
                this.AudioManager.TNT();
                UnityEngine.Object.Destroy(this.gameObject);
            }
        }
    }
}//}