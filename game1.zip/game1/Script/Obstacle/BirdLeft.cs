using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class BirdLeft : MonoBehaviour
    {
        public float Speed;
        private Transform _Player;
        private FxManager FxManager;
        public virtual void Start()
        {
            this.InvokeRepeating("Check", 2f, 2f);
            this._Player = GameObject.FindWithTag("Player").transform;
            this.FxManager = (FxManager)GameObject.FindWithTag("FxManager").GetComponent("FxManager");
        }

        public virtual void Update()
        {
            this.transform.Translate((-Vector3.right * this.Speed) * Time.deltaTime);
        }

        public virtual void Check()
        {
            if ((this.transform.position.x - this._Player.position.x) > 30)
            {
                UnityEngine.Object.Destroy(this.gameObject);
            }
        }

        public virtual void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("KillTrigger"))
            {
                this.GetComponent<Collider2D>().enabled = false;
                this.FxManager.BirdDieFx(this.transform.position);
                UnityEngine.Object.Destroy(this.gameObject);
            }
        }

        public BirdLeft()
        {
            this.Speed = 5f;
        }
    }
}