using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class Smoke : MonoBehaviour
    {
        public float SmokeFinalSize;
        public float AddSize;
        public float Speed;
        public float HorizontalSpeed;
        public float VerticalSpeed;
        public float VerticalSmooth;
        public float HRandom;
        public float VRandom;
        public bool Tractor;
        public bool FixVertical;
        private bool Collid;
        public virtual void Start()
        {
            if (this.Tractor)
            {
                this.VerticalSpeed = this.VerticalSpeed + Random.Range(-this.VRandom, this.VRandom);
                this.HorizontalSpeed = this.HorizontalSpeed + Random.Range(-this.HRandom, this.HRandom);
            }
        }

        public virtual void Update()
        {
            this.transform.Translate((new Vector3(this.VerticalSpeed, this.HorizontalSpeed, 0) * this.Speed) * Time.deltaTime, Space.World);
            if (!this.Tractor)
            {

                {
                    float _117 = this.transform.eulerAngles.z + 0.5f;
                    Vector3 _118 = this.transform.eulerAngles;
                    _118.z = _117;
                    this.transform.eulerAngles = _118;
                }
            }
            if ((this.VerticalSpeed > 0) && !this.FixVertical)
            {
                //VerticalSpeed -= VerticalTime;
                this.VerticalSpeed = Mathf.Lerp(this.VerticalSpeed, 0, Time.deltaTime * this.VerticalSmooth);
            }
            if (this.transform.localScale.x < this.SmokeFinalSize)
            {
                this.transform.localScale = this.transform.localScale + new Vector3(this.AddSize, this.AddSize, this.AddSize);
            }
            if ((this.transform.position.y > 4.8f) && !this.Collid)
            {
                this.GetComponent<Collider2D>().enabled = false;
                this.Collid = true;
            }
            if (this.transform.position.y > 8f)
            {
                UnityEngine.Object.Destroy(this.gameObject);
            }
        }

        public virtual void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("KillTrigger"))
            {
                UnityEngine.Object.Destroy(this.gameObject);
            }
        }

        public Smoke()
        {
            this.SmokeFinalSize = 1f;
            this.AddSize = 0.02f;
            this.Speed = 2f;
            this.HorizontalSpeed = 1f;
        }
    }
}