using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class Tractor : MonoBehaviour
    {
        public Transform Wheel1;
        public Transform Wheel2;
        public float Speed;
        public int WheelSpeed;
        public int Distance;
        public GameObject Smoke1;
        public GameObject Smoke2;
        public Transform SmokePoint1;
        public Transform SmokePoint2;
        public float SmokeTimeRange1;
        public float SmokeTimeRange2;
        private Transform _Player;
        private bool FindPlayer;
        private float SmokeTime1;
        private float SmokeTime2;
        private Animator animator;
        public virtual IEnumerator Start()
        {
            this._Player = GameObject.FindWithTag("Player").transform;
            this.animator = (Animator)this.GetComponent(typeof(Animator));
            this.SmokeTime1 = Time.time + this.SmokeTimeRange1;
            this.SmokeTime2 = Time.time + this.SmokeTimeRange2;
            while (!this.FindPlayer)
            {
                if ((this.transform.position.x - this._Player.position.x) < 12)
                {
                    this.FindPlayer = true;
                    this.StartCoroutine(this.Move());
                }
                yield return new WaitForSeconds(0.35f);
            }
        }

        public virtual IEnumerator Move()
        {
            float dist = this.transform.position.x + this.Distance;
            this.animator.Play("Move", -1, 0);
            while (this.transform.position.x < dist)
            {
                this.transform.Translate((Vector3.right * this.Speed) * Time.deltaTime);
                this.Wheel1.Rotate((Vector3.forward * this.WheelSpeed) * Time.deltaTime);
                this.Wheel2.Rotate(((Vector3.forward * this.WheelSpeed) * 1.5f) * Time.deltaTime);
                if (Time.time > this.SmokeTime1)
                {
                    this.SmokeTime1 = (Time.time + this.SmokeTimeRange1) + Random.Range(0, 0.5f);
                    UnityEngine.Object.Instantiate(this.Smoke1, this.SmokePoint1.position, Quaternion.identity);
                }
                if (Time.time > this.SmokeTime2)
                {
                    this.SmokeTime2 = (Time.time + this.SmokeTimeRange2) + Random.Range(0, 0.5f);
                    UnityEngine.Object.Instantiate(this.Smoke2, this.SmokePoint2.position, Quaternion.identity);
                }
                yield return null;
            }
            this.animator.Play("Idle", -1, 0);
        }

        public Tractor()
        {
            this.Speed = 2f;
            this.WheelSpeed = 40;
            this.Distance = 10;
            this.SmokeTimeRange1 = 1.5f;
            this.SmokeTimeRange2 = 1f;
        }
    }
}