using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class Fance : MonoBehaviour
    {
        public GameObject Bird;
        private AudioManager AudioManager;
        public virtual void Start()
        {
            this.AudioManager = (AudioManager)GameObject.FindWithTag("Audio").GetComponent("AudioManager");
        }

        public virtual void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("Player"))
            {
                this.GetComponent<Animator>().Play("Break", -1, 0);
                this.GetComponent<Collider2D>().enabled = false;
                this.AudioManager.Fance();
                if (this.Bird != null)
                {
                    this.Bird.SendMessage("Fall");
                    //Bird.GetComponent.<Rigidbody2D>().isKinematic = false;
                    this.Bird.GetComponent<Collider2D>().enabled = false;
                    GameObject.FindWithTag("FxManager").SendMessage("Bird1Fx", new Vector3(this.Bird.transform.position.x, this.Bird.transform.position.y, this.Bird.transform.position.z + 0.1f));
                }
            }
        }
    }
}