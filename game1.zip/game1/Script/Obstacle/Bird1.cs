using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class Bird1 : MonoBehaviour
    {
        private Animator animator;
        private AudioManager AudioManager;
        private bool Falling;
        private FxManager FxManager;
        public virtual void Start()
        {
            this.FxManager = (FxManager)GameObject.FindWithTag("FxManager").GetComponent("FxManager");
            this.AudioManager = (AudioManager)GameObject.FindWithTag("Audio").GetComponent("AudioManager");
            this.animator = this.GetComponent<Animator>();
            this.animator.Play("Idle", -1, 0);
            this.StateManager();
        }

        public virtual void StateManager()
        {
            if (this.Falling)
            {
                return;
            }
            int r = Random.Range(0, 3);
            switch (r)
            {
                case 0:
                    this.StartCoroutine(this.Pelk());
                    break;
                case 1:
                    this.StartCoroutine(this.Ghar());
                    break;
                case 2:
                    this.StartCoroutine(this.Turn());
                    break;
            }
        }

        public virtual IEnumerator Pelk()
        {
            if (this.Falling)
            {
                yield break;
            }
            this.animator.Play("Pelk", -1, 0);
            yield return new WaitForSeconds(1.5f);
            this.StateManager();
        }

        public virtual IEnumerator Ghar()
        {
            if (this.Falling)
            {
                yield break;
            }
            this.animator.Play("Ghar", -1, 0);
            this.AudioManager.Bird(this.transform.position.x);
            yield return new WaitForSeconds(2.5f);
            this.StateManager();
        }

        public virtual IEnumerator Turn()
        {
            if (this.Falling)
            {
                yield break;
            }
            this.animator.Play("Turn", -1, 0);
            yield return new WaitForSeconds(2.5f);
            this.StateManager();
        }

        public virtual IEnumerator Fall()
        {
            this.Falling = true;
            this.animator.Play("Fall", -1, 0);
            yield return new WaitForSeconds(1f);
            UnityEngine.Object.Destroy(this.gameObject);
        }

        public virtual void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("KillTrigger"))
            {
                this.GetComponent<Collider2D>().enabled = false;
                this.FxManager.BirdDieFx(this.transform.position);
                UnityEngine.Object.Destroy(this.gameObject);
            }
        }
    }
}