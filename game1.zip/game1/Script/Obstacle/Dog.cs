using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class Dog : MonoBehaviour
    {
        public bool Run;
        public float ChangePos;
        public float speed;
        public Animator BarkFx;
        private Animator animator;
        private float PosA;
        private float PosB;
        private int Direction;
        private AudioManager AudioManager;
        private FxManager FxManager;
        public virtual IEnumerator Start()
        {
            this.AudioManager = (AudioManager)GameObject.FindWithTag("Audio").GetComponent("AudioManager");
            this.FxManager = (FxManager)GameObject.FindWithTag("FxManager").GetComponent("FxManager");
            this.animator = this.GetComponent<Animator>();
            this.animator.Play("Idle", -1, 0);

            {
                float _107 = -0.05f;
                Vector3 _108 = this.transform.position;
                _108.z = _107;
                this.transform.position = _108;
            }
            this.PosA = this.transform.position.x - this.ChangePos;
            this.PosB = this.transform.position.x + this.ChangePos;
            yield return new WaitForSeconds(Random.Range(0, 1.5f));
            this.StateManager();
        }

        public virtual void StateManager()
        {
            if (this.Run)
            {
                this.StartCoroutine(this.RunState());
            }
            else
            {
                this.StartCoroutine(this.Bark());
            }
        }

        public virtual IEnumerator Bark()
        {
            int r = Random.Range(0, 4);
            switch (r)
            {
                case 0:
                    this.animator.Play("Bark", -1, 0);
                    this.BarkFx.Play("Bark", -1, 0);
                    this.AudioManager.DogBark(this.transform.position.x);
                    yield return new WaitForSeconds(0.4f);
                    this.BarkFx.Play("Bark", -1, 0);
                    this.AudioManager.DogBark(this.transform.position.x);
                    break;
                case 1:
                    this.animator.Play("Bark2", -1, 0);
                    this.BarkFx.Play("Bark", -1, 0);
                    this.AudioManager.DogBark(this.transform.position.x);
                    yield return new WaitForSeconds(0.2f);
                    this.AudioManager.DogBark(this.transform.position.x);
                    break;
                case 2:
                    this.animator.Play("Bark3", -1, 0);
                    this.BarkFx.Play("Bark", -1, 0);
                    this.AudioManager.DogBark(this.transform.position.x);
                    break;
                case 3:
                    this.animator.Play("Bark4", -1, 0);
                    this.AudioManager.DogBark(this.transform.position.x);
                    yield return new WaitForSeconds(0.15f);
                    this.BarkFx.Play("Bark", -1, 0);
                    break;
            }
            yield return new WaitForSeconds(1.5f);
            this.StateManager();
        }

        public virtual IEnumerator RunState()
        {
            this.animator.Play("Run", -1, 0);
            if (this.Direction == -1)
            {

                {
                    int _109 = 180;
                    Vector3 _110 = this.transform.eulerAngles;
                    _110.y = _109;
                    this.transform.eulerAngles = _110;
                }
                while (this.transform.position.x > this.PosA)
                {

                    {
                        float _111 = this.transform.position.x - (this.speed * Time.deltaTime);
                        Vector3 _112 = this.transform.position;
                        _112.x = _111;
                        this.transform.position = _112;
                    }
                    yield return null;
                }
            }
            if (this.Direction == 1)
            {

                {
                    int _113 = 0;
                    Vector3 _114 = this.transform.eulerAngles;
                    _114.y = _113;
                    this.transform.eulerAngles = _114;
                }
                while (this.transform.position.x < this.PosB)
                {

                    {
                        float _115 = this.transform.position.x + (this.speed * Time.deltaTime);
                        Vector3 _116 = this.transform.position;
                        _116.x = _115;
                        this.transform.position = _116;
                    }
                    yield return null;
                }
            }
            if (this.Direction == -1)
            {
                this.Direction = 1;
            }
            else
            {
                this.Direction = -1;
            }
            this.animator.Play("Idle", -1, 0);
            this.StartCoroutine(this.Bark());
        }

        public virtual void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("KillTrigger"))
            {
                this.GetComponent<Collider2D>().enabled = false;
                this.FxManager.BirdDieFx(this.transform.position);
                UnityEngine.Object.Destroy(this.gameObject);
            }
        }

        public Dog()
        {
            this.speed = 1.5f;
            this.Direction = -1;
        }
    }
}