using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class Box : MonoBehaviour
    {
        public virtual void OnCollisionEnter2D(Collision2D other) //other.gameObject.GetComponent.<Rigidbody2D>().velocity = Vector2(1.5,2.2);
        {
            if ((other.collider.tag == "Player") && !MyPlayer.Turbo)
            {
                if (other.contacts[0].point.y > (this.transform.position.y + (this.transform.lossyScale.y / 2)))
                {
                    other.gameObject.SendMessage("BoxForce");
                    if ((Random.Range(0, 2) == 0) && (this.transform.localScale.x < 0.5f))
                    {
                        GameObject.FindWithTag("FxManager").SendMessage("Box", this.transform.position);
                        GameObject.Find("AudioManager").SendMessage("Fance");
                        PlayerPrefs.SetInt("BoxBreak", PlayerPrefs.GetInt("BoxBreak") + 1);
                        UnityEngine.Object.Destroy(this.gameObject);
                    }
                }
                else
                {
                }
            }
        }
    }
}