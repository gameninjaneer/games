using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class Magnet : MonoBehaviour
    {
        public Transform _Player;
        public float smoothTime;
        private Vector2 Velocity;
        public virtual void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("Burgar"))
            {
                this.StartCoroutine(this.GoBurgar(other.transform));
            }
        }

        public virtual IEnumerator GoBurgar(Transform obj)
        {
            while (obj)
            {
                //var newPositionx : float = Mathf.SmoothDamp(obj.position.x, _Player.position.x,Velocity.x, smoothTime);
                //var newPositiony : float = Mathf.SmoothDamp(obj.position.y, _Player.position.y,Velocity.y, smoothTime);
                float newPositionx = Mathf.Lerp(obj.position.x, this._Player.position.x, this.smoothTime);
                float newPositiony = Mathf.Lerp(obj.position.y, this._Player.position.y, this.smoothTime);
                obj.position = new Vector3(newPositionx, newPositiony, this._Player.position.z);
                yield return null;
            }
        }

        public Magnet()
        {
            this.smoothTime = 1f;
            this.Velocity = new Vector2(0f, 0f);
        }
    }
}