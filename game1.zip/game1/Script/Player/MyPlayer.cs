using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class MyPlayer : MonoBehaviour
    {
        public int perk;
        public ParticleSystem blast;
        public float Velocity;
        public float DirectionVelocity;
        public float DirectionForce;
        public MapGenerator Map;
        public SpriteRenderer CharacterSprite;
        public Sprite[] CharactersTexture;
        public GameManager GameManager;
        public GameObject FxManager;
        public AudioClip TapSnd;
        public AudioClip BunceSnd;
        public AudioClip DieSnd;
        public GameObject JetEffect;
        public Renderer ShieldEffect;
        public GameObject Magnet, shieldsp;
        public Collider2D KillTrigger;
        public Collider2D KillTriggerSmall;
        public Collider2D KillTriggerRiveve;
        public GameObject PowerTrail;
        public GameObject[] PowerText;
        private float GravityS;
        private bool PlayerDisable;
        private Animator animator;
        private float FirsPos;
        private Rigidbody2D Body;
        private GameDataManager DataManager;
        private AudioSource audioS;
        private AudioManager AudioManager;
        private bool Shield;
        private bool Jet;
        private float TurboCicleTime;
        private float BirdTextTime;
        public static bool isDead;
        public static int Direction;
        public static bool Turbo;
        public static MyPlayer instance;

        public virtual void Start()
        {

            if (instance == null)
            {
                instance = this;
            }
            this.DataManager = new GameDataManager();
            this.AudioManager = (AudioManager)GameObject.FindWithTag("Audio").GetComponent("AudioManager");
            this.audioS = this.GetComponent<AudioSource>();
            MyPlayer.Direction = 1;
            MyPlayer.isDead = false;
            MyPlayer.Turbo = false;
            this.BirdTextTime = Time.time + 30;
            this.Body = this.GetComponent<Rigidbody2D>();
            this.GravityS = this.Body.gravityScale;

            {
                int _119 = 180;
                Vector3 _120 = this.transform.localEulerAngles;
                _120.y = _119;
                this.transform.localEulerAngles = _120;
            }
            this.Body.gravityScale = 0;
            this.animator = (Animator)this.GetComponent(typeof(Animator));
            this.animator.Play("Hanging", -1, 0);
            this.CharacterSprite.sprite = this.CharactersTexture[Random.Range(0, 37)]; //kamran

            // this.CharacterSprite.sprite = this.CharactersTexture[GameDataManager.GetData("PlayerSelect")];
            if (GameDataManager.GetData("MagnetNumber") > 0)
            {
                this.Magnet.SetActive(true);
                switch (GameDataManager.GetData("MagnetUpgrade"))
                {
                    case 0:
                        this.Magnet.transform.localScale = new Vector3(1.1f, 1.1f, 1.1f);
                        break;
                    case 1:
                        this.Magnet.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);
                        break;
                    case 2:
                        this.Magnet.transform.localScale = new Vector3(1.9f, 1.9f, 1.9f);
                        break;
                    case 3:
                        this.Magnet.transform.localScale = new Vector3(2.3f, 2.3f, 2.3f);
                        break;
                    case 4:
                        this.Magnet.transform.localScale = new Vector3(2.7f, 2.7f, 2.7f);
                        break;
                }
            }
        }

        public virtual void SetMagnet()
        {
            if (GameDataManager.GetData("MagnetNumber") > 0)
            {
                this.Magnet.SetActive(true);
                switch (GameDataManager.GetData("MagnetUpgrade"))
                {
                    case 0:
                        this.Magnet.transform.localScale = new Vector3(1.1f, 1.1f, 1.1f);
                        break;
                    case 1:
                        this.Magnet.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);
                        break;
                    case 2:
                        this.Magnet.transform.localScale = new Vector3(1.9f, 1.9f, 1.9f);
                        break;
                    case 3:
                        this.Magnet.transform.localScale = new Vector3(2.3f, 2.3f, 2.3f);
                        break;
                    case 4:
                        this.Magnet.transform.localScale = new Vector3(2.7f, 2.7f, 2.7f);
                        break;
                }
            }
        }

        public virtual void CharacterSelect()
        {
            //  this.CharacterSprite.sprite = this.CharactersTexture[GameDataManager.GetData("PlayerSelect")];
            this.CharacterSprite.sprite = this.CharactersTexture[Random.Range(0, 37)];//kamran
            this.animator.Play("Hanging", -1, 0);
        }

        public virtual IEnumerator PowerTextBird()
        {
            if (Time.time > this.BirdTextTime)
            {
                this.BirdTextTime = (Time.time + 50) + Random.Range(0, 30);
                GameObject BT = UnityEngine.Object.Instantiate(this.PowerText[1], new Vector3(this.transform.position.x - 3, this.transform.position.y, -1), Quaternion.identity);
                BT.transform.parent = this.ShieldEffect.transform;
                yield return new WaitForSeconds(2.5f);
                BT.transform.parent = null;
            }
        }

        public virtual IEnumerator GameStart()
        {
            yield return new WaitForSeconds(0.2f);
            GameManager.Enable = true;
            this.Body.gravityScale = this.GravityS;
            MyPlayer.Direction = 1;
            this.FirsPos = this.transform.position.x;
            this.Body.angularVelocity = -175;
            this.animator.Play("Idle", -1, 0);
        }

        public virtual void Update()
        {
            if (this.PlayerDisable)
            {
                return;
            }
            if (MyPlayer.isDead || !GameManager.Enable)
            {
                return;
            }
            float s = (this.transform.position.x - this.FirsPos) / 3;
            if (s > GameManager.Score)
            {
                GameManager.Score = (int)s;
            }
            if (MyPlayer.Turbo)
            {
                if ((this.transform.position.y < -1.7f) && (this.TurboCicleTime < Time.time))
                {

                    {
                        float _121 = this.Velocity * 2.9f;
                        Vector2 _122 = this.Body.velocity;
                        _122.y = _121;
                        this.Body.velocity = _122;
                    }

                    {
                        float _123 = (MyPlayer.Direction * this.DirectionVelocity) * 1.6f;
                        Vector2 _124 = this.Body.velocity;
                        _124.x = _123;
                        this.Body.velocity = _124;
                    }
                    this.FxManager.SendMessage("CircleFx", new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z + 0.1f));
                    this.audioS.PlayOneShot(this.BunceSnd, 0.5f);
                    this.TurboCicleTime = Time.time + 0.05f;
                    this.Body.angularVelocity = -675;
                    this.animator.Play("Turn", -1, 0);
                }
                if ((this.transform.position.y > 3.5f) && (this.TurboCicleTime < Time.time))
                {

                    {
                        float _125 = this.Velocity * -2.9f;
                        Vector2 _126 = this.Body.velocity;
                        _126.y = _125;
                        this.Body.velocity = _126;
                    }

                    {
                        float _127 = (MyPlayer.Direction * this.DirectionVelocity) * 1.6f;
                        Vector2 _128 = this.Body.velocity;
                        _128.x = _127;
                        this.Body.velocity = _128;
                    }
                    this.FxManager.SendMessage("CircleFx", new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z + 0.1f));
                    this.audioS.PlayOneShot(this.BunceSnd, 0.5f);
                    this.TurboCicleTime = Time.time + 0.05f;
                    this.Body.angularVelocity = -675;
                    this.animator.Play("Turn", -1, 0);
                }
            }
            if (this.Jet)
            {

                {
                    float _129 = this.JetEffect.transform.localEulerAngles.z - (7000 * Time.deltaTime);
                    Vector3 _130 = this.JetEffect.transform.localEulerAngles;
                    _130.z = _129;
                    this.JetEffect.transform.localEulerAngles = _130;
                }
            }
            if ((Input.GetButtonDown("Fire1") && !GameManager.InMenu) && !MyPlayer.Turbo) // Main Tap
            {
                if (this.transform.position.y < 3.8f)
                {

                    {
                        float _131 = this.Velocity;
                        Vector2 _132 = this.Body.velocity;
                        _132.y = _131;
                        this.Body.velocity = _132;
                    }
                    if (!this.Jet)
                    {

                        {
                            float _133 = MyPlayer.Direction * this.DirectionVelocity;
                            Vector2 _134 = this.Body.velocity;
                            _134.x = _133;
                            this.Body.velocity = _134;
                        }
                    }
                }
                else
                {
                    if (this.transform.position.y < 4.2f)
                    {

                        {
                            float _135 = this.Velocity / 3.4f;
                            Vector2 _136 = this.Body.velocity;
                            _136.y = _135;
                            this.Body.velocity = _136;
                        }
                        if (!this.Jet)
                        {

                            {
                                float _137 = MyPlayer.Direction * this.DirectionVelocity;
                                Vector2 _138 = this.Body.velocity;
                                _138.x = _137;
                                this.Body.velocity = _138;
                            }
                        }
                    }
                }
                this.animator.Play("Flapp", -1, 0);
                this.audioS.PlayOneShot(this.TapSnd, 0.3f);
                PlayerPrefs.SetInt("Tap", PlayerPrefs.GetInt("Tap") + 1);
            }
            if (MyPlayer.Direction > 0)
            {
                if (this.Body.velocity.x > 0.5f)
                {

                    {
                        float _139 = this.Body.velocity.x - 0.02f;
                        Vector2 _140 = this.Body.velocity;
                        _140.x = _139;
                        this.Body.velocity = _140;
                    }
                }
            }
            else
            {
                if (MyPlayer.Direction < 0)
                {
                    if (this.Body.velocity.x < -0.5f)
                    {

                        {
                            float _141 = this.Body.velocity.x + 0.02f;
                            Vector2 _142 = this.Body.velocity;
                            _142.x = _141;
                            this.Body.velocity = _142;
                        }
                    }
                }
            }
        }

        public virtual IEnumerator JetStart()
        {
            if ((MyPlayer.Turbo || this.Shield) || this.Jet)
            {
                yield break;
            }
            this.Jet = true;

            {
                int _143 = 0;
                Vector2 _144 = this.Body.velocity;
                _144.y = _143;
                this.Body.velocity = _144;
            }

            {
                float _145 = (MyPlayer.Direction * this.DirectionVelocity) * 2.8f;
                Vector2 _146 = this.Body.velocity;
                _146.x = _145;
                this.Body.velocity = _146;
            }
            this.JetEffect.GetComponent<SpriteRenderer>().enabled = true;
            float dist = this.transform.position.x + 55;
            this.PowerTrail.transform.position = this.transform.position;
            this.PowerTrail.SetActive(true);
            while (this.transform.position.x < dist)
            {

                {
                    float _147 = (MyPlayer.Direction * this.DirectionVelocity) * 2.3f;
                    Vector2 _148 = this.Body.velocity;
                    _148.x = _147;
                    this.Body.velocity = _148;
                }
                this.Body.AddForce(new Vector2(0, 30));
                yield return null;
            }
            this.Jet = false;
            this.Body.gravityScale = this.GravityS;
            this.JetEffect.GetComponent<SpriteRenderer>().enabled = false;

            {
                float _149 = (MyPlayer.Direction * this.DirectionVelocity) * 2;
                Vector2 _150 = this.Body.velocity;
                _150.x = _149;
                this.Body.velocity = _150;
            }
            this.Body.angularVelocity = -175;
            this.animator.Play("Flapp", -1, 0);
            this.PowerTrail.SetActive(false);
        }

        public virtual IEnumerator ShieldStart(int type)
        {
            if ((MyPlayer.Turbo || this.Shield) || this.Jet)
            {
                yield break;
            }

            this.Shield = true;
            this.KillTriggerSmall.enabled = true;
            //kamran   killtriggersmall
            if (type == 0)
            {
                if (GameDataManager.GetData("ShieldNumber") > 0)
                {
                    this.DataManager.SetData("ShieldNumber", GameDataManager.GetData("ShieldNumber") - 1);
                }
            }
            PlayerPrefs.SetInt("UseShield", PlayerPrefs.GetInt("UseShield") + 1);
            ((SpriteRenderer)this.ShieldEffect.GetComponent(typeof(SpriteRenderer))).color = new Color(1, 1, 1, 1);
            this.ShieldEffect.enabled = true;
            this.gameObject.layer = 12;
            switch (GameDataManager.GetData("ShieldUpgrade"))
            {
                case 0:
                    yield return new WaitForSeconds(6);
                    break;
                case 1:
                    yield return new WaitForSeconds(7.5f);
                    break;
                case 2:
                    yield return new WaitForSeconds(9);
                    break;
                case 3:
                    yield return new WaitForSeconds(10.2f);
                    break;
                case 4:
                    yield return new WaitForSeconds(11.4f);
                    break;
            }
            ((SpriteRenderer)this.ShieldEffect.GetComponent(typeof(SpriteRenderer))).color = new Color(1, 0f, 0f, 1);
            yield return new WaitForSeconds(2);
            if (this.gameObject.layer == 12)
            {
                this.Shield = false;
            }
            this.KillTrigger.enabled = true;
            this.KillTriggerSmall.enabled = false;
            yield return new WaitForSeconds(0.2f);
            this.KillTrigger.enabled = false;
            this.ShieldEffect.enabled = false;
            this.gameObject.layer = 11;
        }

        public virtual IEnumerator TurboStart(int type)
        {
            if ((MyPlayer.Turbo || this.Shield) || this.Jet)
            {
                yield break;
            }
            MyPlayer.Turbo = true;
            this.KillTriggerSmall.enabled = true;
            this.FxManager.SendMessage("CircleFx", new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z + 0.1f));
            if (type == 0)
            {
                if (GameDataManager.GetData("TurboNumber") > 0)
                {
                    this.DataManager.SetData("TurboNumber", GameDataManager.GetData("TurboNumber") - 1);
                }
            }
            PlayerPrefs.SetInt("UseTurbo", PlayerPrefs.GetInt("UseTurbo") + 1);
            this.PowerTrail.transform.position = this.transform.position;
            this.PowerTrail.SetActive(true);
            this.gameObject.layer = 12;

            {
                float _151 = this.Velocity * 5;
                Vector2 _152 = this.Body.velocity;
                _152.y = _151;
                this.Body.velocity = _152;
            }

            {
                float _153 = MyPlayer.Direction * this.DirectionVelocity;
                Vector2 _154 = this.Body.velocity;
                _154.x = _153;
                this.Body.velocity = _154;
            }
            switch (GameDataManager.GetData("TurboUpgrade"))
            {
                case 0:
                    yield return new WaitForSeconds(3f);
                    break;
                case 1:
                    yield return new WaitForSeconds(4.5f);
                    break;
                case 2:
                    yield return new WaitForSeconds(6f);
                    break;
                case 3:
                    yield return new WaitForSeconds(7.1f);
                    break;
                case 4:
                    yield return new WaitForSeconds(8.2f);
                    break;
            }
            MyPlayer.Turbo = false;

            {
                float _155 = this.Velocity;
                Vector2 _156 = this.Body.velocity;
                _156.y = _155;
                this.Body.velocity = _156;
            }

            {
                float _157 = MyPlayer.Direction * this.DirectionVelocity;
                Vector2 _158 = this.Body.velocity;
                _158.x = _157;
                this.Body.velocity = _158;
            }
            this.FxManager.SendMessage("CircleFx", new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z + 0.1f));
            this.KillTrigger.enabled = true;
            this.KillTriggerSmall.enabled = false;
            yield return new WaitForSeconds(0.2f);
            this.gameObject.layer = 11;
            this.KillTrigger.enabled = false;
            this.PowerTrail.SetActive(false);
        }

        public virtual void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("magnettag"))
            {
                this.AudioManager.AddPowerup();

                perk++;
                Debug.Log("magnet called");
                other.gameObject.SetActive(false);
                this.Magnet.SetActive(true);
                StartCoroutine(stopmagnet());

            }
            if (other.CompareTag("bomb"))
            {
                perk++;
                Debug.Log("bomb called");
                other.gameObject.SetActive(false);
                blast.Play();
                this.AudioManager.powerupscollect();

                //this.Magnet.SetActive(true);
                this.KillTriggerRiveve.enabled = true;

                StartCoroutine(stopreviv());

            }

            if (other.CompareTag("shield"))
            {
                this.AudioManager.AddPowerup();

                perk++;
                Debug.Log("magnet called");
                other.gameObject.SetActive(false);
                this.shieldsp.SetActive(true);
                StartCoroutine(shieldstop());

            }
            if (MyPlayer.isDead)
            {
                return;
            }
            if (other.CompareTag("DeadZone"))
            {
                other.GetComponent<Collider2D>().enabled = false;
                this.StartCoroutine(this.Die());
            }
            if (other.CompareTag("Obstacle"))
            {
                this.StartCoroutine(this.Die());
            }
            if (other.CompareTag("Pass"))
            {
                other.GetComponent<Collider2D>().enabled = false;
                this.Map.Generate();
            }
            if (other.CompareTag("Burgar"))
            {
                this.FxManager.SendMessage("GetBurgarFx", other.transform.position + new Vector3(0, 0, 0.5f));
                this.AudioManager.GetBurgar();
                if (PlayerPrefs.GetInt("double_burgar_sbm") == 0)
                {
                    if (GameDataManager.GetData("PlayerSelect") < 30)
                    {
                        this.DataManager.GiveBurgar(1);
                        GameManager.InPlayBurger = GameManager.InPlayBurger + 1;
                    }
                    else
                    {
                        this.DataManager.GiveBurgar(2);
                        GameManager.InPlayBurger = GameManager.InPlayBurger + 2;
                    }
                }
                else
                {
                    if (GameDataManager.GetData("PlayerSelect") < 30)
                    {
                        this.DataManager.GiveBurgar(2);
                        GameManager.InPlayBurger = GameManager.InPlayBurger + 2;
                    }
                    else
                    {
                        this.DataManager.GiveBurgar(4);
                        GameManager.InPlayBurger = GameManager.InPlayBurger + 4;
                    }
                }
                UnityEngine.Object.Destroy(other.gameObject);
                PlayerPrefs.SetInt("EarnBurger", PlayerPrefs.GetInt("EarnBurger") + 1);
            }
            if (other.CompareTag("BurgarBig"))
            {
                this.FxManager.SendMessage("GetBurgarFx", other.transform.position + new Vector3(0, 0, 0.5f));
                this.AudioManager.GetBurgar();
                if (PlayerPrefs.GetInt("double_burgar_sbm") == 0)
                {
                    if (GameDataManager.GetData("PlayerSelect") < 30)
                    {
                        this.DataManager.GiveBurgar(3);
                        GameManager.InPlayBurger = GameManager.InPlayBurger + 3;
                    }
                    else
                    {
                        this.DataManager.GiveBurgar(6);
                        GameManager.InPlayBurger = GameManager.InPlayBurger + 3;
                    }
                }
                else
                {
                    if (GameDataManager.GetData("PlayerSelect") < 30)
                    {
                        this.DataManager.GiveBurgar(6);
                        GameManager.InPlayBurger = GameManager.InPlayBurger + 6;
                    }
                    else
                    {
                        this.DataManager.GiveBurgar(12);
                        GameManager.InPlayBurger = GameManager.InPlayBurger + 12;
                    }
                }
                UnityEngine.Object.Destroy(other.gameObject);
                PlayerPrefs.SetInt("EarnBurger", PlayerPrefs.GetInt("EarnBurger") + 3);
                PlayerPrefs.SetInt("EarnDoubleBurger", PlayerPrefs.GetInt("EarnDoubleBurger") + 1);
            }
            if (other.CompareTag("Jet"))
            {
                this.AudioManager.GetBurgar();
                this.FxManager.SendMessage("CircleFx", other.transform.position + new Vector3(0, 0, 1));
                other.GetComponent<Collider2D>().enabled = false;
                this.Map.SetJet();
                this.StartCoroutine(this.JetStart());
                //BurgerText();
                UnityEngine.Object.Destroy(other.gameObject);
            }
            if (other.CompareTag("SkyChanger"))
            {
                other.GetComponent<Collider2D>().enabled = false;
                this.StartCoroutine(this.Map.SkyChange());
            }
        }
        IEnumerator stopmagnet()
        {
            yield return new WaitForSeconds(5f);
            this.Magnet.SetActive(false);
            print("magnert is false");
        }
        IEnumerator stopreviv()
        {
            yield return new WaitForSeconds(1f);
            this.KillTriggerRiveve.enabled = false;
            this.KillTriggerSmall.enabled = false;

            print("bbb is false");
        }

        IEnumerator shieldstop()
        {
            yield return new WaitForSeconds(5f);
            this.shieldsp.SetActive(false);
            print("shield is false");
        }
        public virtual IEnumerator BurgerText()
        {
            GameObject BT2 = UnityEngine.Object.Instantiate(this.PowerText[0], new Vector3(this.transform.position.x + 3, this.transform.position.y, -1), Quaternion.identity);
            BT2.transform.parent = this.ShieldEffect.transform;
            yield return new WaitForSeconds(2.5f);
            BT2.transform.parent = null;
        }

        public virtual void OnCollisionEnter2D(Collision2D other)
        {


            if (MyPlayer.isDead)
            {
                return;
            }
            if (other.collider.tag == "Obstacle")
            {
                this.StartCoroutine(this.Die());
            }
            if (other.collider.tag == "TNT")
            {
                this.FxManager.SendMessage("TNTExplod", other.transform.position);
                this.AudioManager.TNT();
                this.StartCoroutine(this.Die());
                UnityEngine.Object.Destroy(other.gameObject);
            }
            if (other.collider.tag == "Fance")
            {
                this.StartCoroutine(this.Die());
            }
            if (other.collider.tag == "Ground")
            {
                MyPlayer.Direction = 1;

                {
                    float _159 = (MyPlayer.Direction * this.DirectionForce) * 1.7f;
                    Vector2 _160 = this.Body.velocity;
                    _160.x = _159;
                    this.Body.velocity = _160;
                }

                {
                    float _161 = this.DirectionForce * 3.25f;
                    Vector2 _162 = this.Body.velocity;
                    _162.y = _161;
                    this.Body.velocity = _162;
                }
                this.Body.angularVelocity = -375;
                this.animator.Play("Turn", -1, 0);
                this.audioS.PlayOneShot(this.BunceSnd, 0.5f);
            }
            if (MyPlayer.Turbo && (other.gameObject.layer == 10))
            {

                {
                    float _163 = this.Velocity * 2.9f;
                    Vector2 _164 = this.Body.velocity;
                    _164.y = _163;
                    this.Body.velocity = _164;
                }

                {
                    float _165 = (MyPlayer.Direction * this.DirectionVelocity) * 1.6f;
                    Vector2 _166 = this.Body.velocity;
                    _166.x = _165;
                    this.Body.velocity = _166;
                }
                //FxManager.SendMessage("CircleFx",Vector3(transform.position.x,transform.position.y,transform.position.z + 0.1));
                this.audioS.PlayOneShot(this.BunceSnd, 0.5f);
                this.Body.angularVelocity = -675;
                this.animator.Play("Turn", -1, 0);
                this.TurboCicleTime = Time.time + 0.05f;
            }
        }

        public virtual IEnumerator Revive()
        {
            yield return new WaitForSeconds(0.4f);
            this.StartCoroutine(this.Hurt());
            MyPlayer.Direction = 1;
            MyPlayer.isDead = false;
            this.AudioManager.GameOver();
            if (this.transform.position.y < -2.6f)
            {

                {
                    int _167 = 0;
                    Vector3 _168 = this.transform.position;
                    _168.y = _167;
                    this.transform.position = _168;
                }
            }
            this.Body.isKinematic = false;
            this.Body.simulated = true;
            this.GetComponent<Collider2D>().enabled = true;
            this.animator.Play("Flapp", -1, 0);

            {
                float _169 = this.Velocity;
                Vector2 _170 = this.Body.velocity;
                _170.y = _169;
                this.Body.velocity = _170;
            }

            {
                float _171 = MyPlayer.Direction * this.DirectionVelocity;
                Vector2 _172 = this.Body.velocity;
                _172.x = _171;
                this.Body.velocity = _172;
            }
            this.Body.angularVelocity = -175;
        }

        public virtual IEnumerator BoxForce()
        {
            yield return new WaitForSeconds(0.1f);
            if (MyPlayer.isDead)
            {
                yield break;
            }
            this.Body.velocity = new Vector2(4.7f, 6.5f);
            this.Body.angularVelocity = -375;
            this.animator.Play("BoxTurn", -1, 0);
        }

        public virtual IEnumerator Hurt()
        {
            this.gameObject.layer = 12;
            this.KillTriggerRiveve.enabled = true;
            yield return new WaitForSeconds(0.2f);
            this.KillTriggerRiveve.enabled = false;
            this.gameObject.layer = 11;
        }

        public virtual IEnumerator Die()
        {
            MyPlayer.isDead = true;
            MyPlayer.Direction = 0;
            this.animator.Play("Die", -1, 0);
            this.audioS.PlayOneShot(this.DieSnd, 0.7f);
            this.Body.isKinematic = true;
            this.Body.simulated = false;
            this.GetComponent<Collider2D>().enabled = false;
            this.ShieldEffect.enabled = false;
            this.PowerTrail.SetActive(false);
            this.GameManager.GameOver();
            yield return new WaitForSeconds(0.5f);
            this.FxManager.SendMessage("BubbleManDie", this.transform.position);
        }

        static MyPlayer()
        {
            MyPlayer.Direction = 1;
        }

    }

}