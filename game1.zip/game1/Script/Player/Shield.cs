using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class Shield : MonoBehaviour
    {
        public Transform _Player;
        public virtual void Update()
        {
            this.transform.position = this._Player.position + new Vector3(0, 0, 0.1f);
        }
    }
}