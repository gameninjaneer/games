using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class GameManager : MonoBehaviour
    {
        public GameObject tutbuton;
        public int scorehealthcoun = 3;
        public GameObject magnetscript;
        public GameObject myUi;
        public MyPlayer Player;
        public static GameManager instance;
        public MenuManager MenuManager;
        //public string AndroidRateURL;
        //public string iOSRateURL;
        public static int Score;
        public static int Stage;
        public static bool Enable;
        public static bool InMenu;
        public static int ReviveNumber;
        public static bool Night;
        public static bool Noon;
        public static bool InGameOver;
        public static int ReviveVideo;
        public static int InPlayBurger;
        private bool PlayBtnDisable;
        private GameDataManager DataManager;
        public int healthcounter = 3;
        public GameObject[] healthPng;
        private AudioManager AudioManager;

       
        public virtual void Start()
        {
            if (instance == null)
            {
                instance = this;
            }
            GameManager.Score = 0;
            GameManager.Stage = 0;
            GameManager.Enable = false;
            GameManager.InMenu = false;
            GameManager.ReviveNumber = 20;
            GameManager.Night = false;
            GameManager.Noon = false;
            GameManager.InGameOver = false;
            GameManager.ReviveVideo = 0;
            GameManager.InPlayBurger = 0;
            this.DataManager = new GameDataManager();
            if (((PlayerPrefs.GetInt("TodayGamePlay") % 4) == 0) && (PlayerPrefs.GetInt("TodayGamePlay") != 0))
            {
                //GameObject.Find("AdManager").SendMessage("ShowUnityVideo");
            }
            this.AudioManager = (AudioManager)GameObject.FindWithTag("Audio").GetComponent("AudioManager");
            STARTBUTTON();
        }

        public virtual void Update()
        {
            GameManager.Stage = GameManager.Score / 50;
            if (GameManager.Stage > 6)
            {
                GameManager.Stage = 6;
            }
        }
        public void STARTBUTTON()
        {

           
            GameStart();
        }
        public void GameStart()
        {
            tutbuton.SetActive(false);
            myUi.SetActive(true);
            Timer.instance.timerIsRunning = true;

            if (this.PlayBtnDisable)
            {
                return;
            }
            this.StartCoroutine(this.MenuManager.MainMenuGoUp());
            this.StartCoroutine(this.Player.GameStart());
            this.StartCoroutine(this.MenuManager.PlayMenuGoDown());
            this.StartCoroutine(this.SceneDeactive());
            PlayerPrefs.SetInt("GamePlayed", PlayerPrefs.GetInt("GamePlayed") + 1);
            PlayerPrefs.SetInt("TodayGamePlay", PlayerPrefs.GetInt("TodayGamePlay") + 1);
        }

        public virtual IEnumerator SceneDeactive()
        {
            this.PlayBtnDisable = true;
            yield return new WaitForSeconds(1.6f);
            this.PlayBtnDisable = false;
        }

        public virtual void VideoRevive()
        {
            this.StartCoroutine(this.Player.Revive());
            this.StartCoroutine(this.MenuManager.Revive());
        }

        public virtual void VideoBurgar()
        {
            this.DataManager.GiveBurgar(50);
        }

        public virtual void Pause()
        {
            this.MenuManager.Pause();
        }

        public virtual void Resume()
        {
            this.StartCoroutine(this.MenuManager.Resume());
        }

        public virtual void Restart()
        {

            this.StartCoroutine(this.MenuManager.Restart());

        }

        public virtual void GameOver()
        {
            healthcounter--;

          //  healthPng[healthcounter].SetActive(false);
            print(healthcounter);
            if (healthcounter > 0)
            {
                scorehealthcoun--;
                myRevive();
            }
            else
            {
                scorehealthcoun--;
                this.AudioManager.WinCharacter();
                this.StartCoroutine(this.MenuManager.GameOver());

            }
        }
        public bool endtime = false;
        public bool endmatch = false;
        public void endgame()
        {
            this.AudioManager.WinCharacter();

            //GameOver();
            //Resume();
            endmatch = true;
            Time.timeScale = 0;
            this.StartCoroutine(this.MenuManager.GameOver());

        }

        public void endgameTime()
        {
            //GameOver();
            //Resume();
            this.AudioManager.WinCharacter();
            endtime = true;
            Time.timeScale = 0;
            this.StartCoroutine(this.MenuManager.GameOver());

        }
        public void myRevive()
        {
            this.DataManager.TakeBurgar(GameManager.ReviveNumber);
            GameManager.ReviveNumber = GameManager.ReviveNumber * 2;
            this.StartCoroutine(this.Player.Revive());
            this.StartCoroutine(this.MenuManager.Revive());
        }
        public virtual void Revive()
        {
            if (GameManager.ReviveNumber <= this.DataManager.GetBurgar())
            {
                this.DataManager.TakeBurgar(GameManager.ReviveNumber);
                GameManager.ReviveNumber = GameManager.ReviveNumber * 2;
                this.StartCoroutine(this.Player.Revive());
                this.StartCoroutine(this.MenuManager.Revive());
            }
        }

        public virtual void OpenURL(int type)
        {
            //if (type == 0)
            //{
            //    if (Application.platform == RuntimePlatform.Android)
            //    {
            //        Application.OpenURL(this.AndroidRateURL);
            //    }
            //    else
            //    {
            //        Application.OpenURL(this.iOSRateURL);
            //    }
            //}

            if (type == 1)
            {

            }

            if (type == 2)
            {

            }
        }

        public virtual void Share()
        {

        }

        public virtual void SetTurbo()
        {
            if (GameDataManager.GetData("TurboNumber") > 0)
            {
                this.StartCoroutine(this.Player.TurboStart(0));
                this.MenuManager.ShowPuwerUps();
            }
        }

        public virtual void SetShield()
        {
            if (GameDataManager.GetData("ShieldNumber") > 0)
            {
                this.StartCoroutine(this.Player.ShieldStart(0));
                this.MenuManager.ShowPuwerUps();
            }
        }

        public virtual void WatchVideo()
        {
            //GameManager.ReviveVideo = GameManager.ReviveVideo + 1;
            //GameObject.Find("AdManager").SendMessage("ShowUnityRewardedVideo");
        }

        public virtual void WatchVideoBurgar()
        {
            //GameObject.Find("AdManager").SendMessage("ShowUnityBurgarRewardedVideo");
        }

        public virtual void ShowLeaderboard()
        {
            //GameObject.Find("CBSocial").SendMessage("ShowLeaderboard");
        }

        public virtual void ShowAchivment()
        {
            //GameObject.Find("CBSocial").SendMessage("ShowAchievement");
        }
    }
}

