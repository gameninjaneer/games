using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public class GameDataManager : object
    {
        // -------- Data --------------------------------------------
        public static int GetData(string Name)
        {
            return UnityEngine.PlayerPrefs.GetInt(Name);
        }

        public virtual void SetData(string Name, int Num)
        {
            UnityEngine.PlayerPrefs.SetInt(Name, Num);
        }

        // -------- Burgar --------------------------------------------
        public virtual int GetBurgar()
        {
            //return StoreInventory.GetItemBalance("currency_burgar");
            return UnityEngine.PlayerPrefs.GetInt("currency_burgar");
        }

        public virtual void GiveBurgar(int Num)
        {
            //StoreInventory.GiveItem("currency_burgar",Num);
            UnityEngine.PlayerPrefs.SetInt("currency_burgar", UnityEngine.PlayerPrefs.GetInt("currency_burgar") + Num);
        }

        public virtual void TakeBurgar(int Num)
        {
            UnityEngine.PlayerPrefs.SetInt("currency_burgar", UnityEngine.PlayerPrefs.GetInt("currency_burgar") - Num);
        }
    }
}