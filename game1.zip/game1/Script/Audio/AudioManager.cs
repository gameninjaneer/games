using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]

    public partial class AudioManager : MonoBehaviour
    {
        public AudioClip DogBarkSnd;
        public AudioClip BirdkSnd;
        public AudioClip GetBurgarkSnd;
        public AudioClip FanceSnd;
        public AudioClip powerCollectbomb;
        public AudioClip SlotMachinMoveSnd;
        public AudioClip WinCharacterSnd;
        public AudioClip ButtonClickSnd;
        public AudioClip GameOverSnd;
        public AudioClip ReviveSnd;
        public AudioClip GiftBtnSnd;
        public AudioClip NoMoneySnd;
        public AudioClip AddPowerupSnd;
        public AudioClip TntSnd;
        public AudioClip JhonCenaSnd;
        public AudioSource PlayerAudioSource;
        public AudioSource CameraAudioSource;
        public UnityEngine.UI.Image[] VoiceBTN;
        public UnityEngine.UI.Image[] MusicBTN;
        public Sprite VoiceBTNoffTexture;
        public Sprite MusicBTNoffTexture;
        private AudioSource audioS;
        private Transform _player;
        private bool BirdSndOn;
        private bool DogSndOn;
        private Sprite VoiceBTNonTexture;
        private Sprite MusicBTNonTexture;
        public virtual void Start()
        {
            this.audioS = this.GetComponent<AudioSource>();
            this._player = GameObject.FindWithTag("Player").transform;
            this.VoiceBTNonTexture = this.VoiceBTN[0].sprite;
            this.MusicBTNonTexture = this.MusicBTN[0].sprite;
            this.RefreshAudio();
        }

        public virtual void DogBark(float dist)
        {
            if (this.DogSndOn)
            {
                return;
            }
            if (Vector2.Distance(new Vector2(0, dist), new Vector2(0, this._player.position.y)) < 11)
            {
                this.DogSndOn = true;
                this.StartCoroutine(this.SndOFF(2));
                this.audioS.PlayOneShot(this.DogBarkSnd, Random.Range(0.1f, 0.32f));
            }
        }

        public virtual void Bird(float dist)
        {
            if (this.BirdSndOn)
            {
                return;
            }
            if (Vector2.Distance(new Vector2(0, dist), new Vector2(0, this._player.position.y)) < 11)
            {
                this.BirdSndOn = true;
                this.StartCoroutine(this.SndOFF(1));
                this.audioS.PlayOneShot(this.BirdkSnd, Random.Range(0.1f, 0.35f));
            }
        }

        public virtual void GetBurgar()
        {
            print("collected burger");
            this.audioS.PlayOneShot(this.GetBurgarkSnd, 0.7f);
        }

        public virtual void Fance()
        {
            this.audioS.PlayOneShot(this.FanceSnd, 0.5f);
        }
        public virtual void powerupscollect()
        {
            this.audioS.PlayOneShot(this.powerCollectbomb, 0.7f);
        }

        public virtual void TNT()
        {

            this.audioS.PlayOneShot(this.TntSnd, 0.35f);
        }

        public virtual void JhonCena()
        {
            this.audioS.PlayOneShot(this.JhonCenaSnd, 0.9f);
        }

        public virtual IEnumerator SndOFF(int type)
        {
            if (type == 1)
            {
                yield return new WaitForSeconds(0.6f);
                this.BirdSndOn = false;
            }
            if (type == 2)
            {
                yield return new WaitForSeconds(0.2f);
                this.DogSndOn = false;
            }
        }

        public virtual void SlotMachinMove()
        {
            this.audioS.PlayOneShot(this.SlotMachinMoveSnd, 0.35f);
        }

        public virtual void WinCharacter()
        {
            this.audioS.PlayOneShot(this.WinCharacterSnd, 0.8f);
        }

        public virtual void ButtonClick()
        {
            this.audioS.PlayOneShot(this.ButtonClickSnd, 0.5f);
        }

        public virtual void GameOver()
        {
            this.audioS.PlayOneShot(this.GameOverSnd, 0.8f);
        }

        public virtual void Revive()
        {
            this.audioS.PlayOneShot(this.ReviveSnd, 1f);
        }

        public virtual void GiftBTN()
        {
            this.audioS.PlayOneShot(this.GiftBtnSnd, 0.9f);
        }

        public virtual void NoMoney()
        {
            this.audioS.PlayOneShot(this.NoMoneySnd, 0.6f);
        }

        public virtual void AddPowerup()
        {
            this.audioS.PlayOneShot(this.AddPowerupSnd, 0.7f);
        }

        public virtual void VoiceSet()
        {
            if (PlayerPrefs.GetInt("VoiceVolium") == 0)
            {
                PlayerPrefs.SetInt("VoiceVolium", 1);
            }
            else
            {
                PlayerPrefs.SetInt("VoiceVolium", 0);
            }
            this.RefreshAudio();
        }

        public virtual void MusicSet()
        {
            if (PlayerPrefs.GetInt("MusicVolium") == 0)
            {
                PlayerPrefs.SetInt("MusicVolium", 1);
            }
            else
            {
                PlayerPrefs.SetInt("MusicVolium", 0);
            }
            this.RefreshAudio();
        }

        public virtual void RefreshAudio()
        {
            this.PlayerAudioSource.volume = PlayerPrefs.GetInt("VoiceVolium");
            this.audioS.volume = PlayerPrefs.GetInt("VoiceVolium");
            if (PlayerPrefs.GetInt("MusicVolium") == 0)
            {
                this.CameraAudioSource.volume = 0;
            }
            else
            {
                this.CameraAudioSource.volume = 0.3f;
            }
            if (PlayerPrefs.GetInt("MusicVolium") != 0)
            {
                this.MusicBTN[0].sprite = this.MusicBTNonTexture;
                this.MusicBTN[1].sprite = this.MusicBTNonTexture;
            }
            else
            {
                this.MusicBTN[0].sprite = this.MusicBTNoffTexture;
                this.MusicBTN[1].sprite = this.MusicBTNoffTexture;
            }
            if (PlayerPrefs.GetInt("VoiceVolium") != 0)
            {
                this.VoiceBTN[0].sprite = this.VoiceBTNonTexture;
                this.VoiceBTN[1].sprite = this.VoiceBTNonTexture;
            }
            else
            {
                this.VoiceBTN[0].sprite = this.VoiceBTNoffTexture;
                this.VoiceBTN[1].sprite = this.VoiceBTNoffTexture;
            }
        }

    }
}