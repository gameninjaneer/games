using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

namespace BMRolling
{
    [System.Serializable]
    public partial class Startup : MonoBehaviour
    {
        public virtual IEnumerator Start()
        {
            Application.targetFrameRate = 60;
            QualitySettings.vSyncCount = 0;
            PlayerPrefs.SetInt("TodayGamePlay", 0);
            if (PlayerPrefs.GetInt("GameOpen") == 0)
            {
                PlayerPrefs.SetInt("GameOpen", 1);
                PlayerPrefs.SetString("LastTimePlayed", "10/10/2010 12:10:10 AM");
                PlayerPrefs.SetInt("MusicVolium", 1);
                PlayerPrefs.SetInt("VoiceVolium", 1);
            }
            //PlayerPrefs.SetInt("ShieldNumber",1);
            //PlayerPrefs.SetInt("TurboNumber",1);
            yield return new WaitForSeconds(2);
            SceneManager.LoadScene(1);
        }
    }
}