using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class StartupCanvas : MonoBehaviour
    {
        public virtual void Start()
        {
            UnityEngine.Object.DontDestroyOnLoad(this.gameObject);
        }
    }
}