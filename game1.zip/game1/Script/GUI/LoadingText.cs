using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class LoadingText : MonoBehaviour
    {
        public UnityEngine.UI.Text T;
        private string[] texts;
        private int TNumber;
        public virtual void Start()
        {
            this.InvokeRepeating("ShowText", 1, 0.1f);
            this.texts = new string[5];
            this.texts[0] = "LOADING";
            this.texts[1] = "LOADING.";
            this.texts[2] = "LOADING..";
            this.texts[3] = "LOADING...";
            this.texts[4] = "LOADING....";
            this.T = this.GetComponent<UnityEngine.UI.Text>();
        }

        public virtual void ShowText()
        {
            this.T.text = this.texts[this.TNumber];
            this.TNumber = this.TNumber + 1;
            if (this.TNumber > 4)
            {
                this.TNumber = 0;
            }
        }
    }
}