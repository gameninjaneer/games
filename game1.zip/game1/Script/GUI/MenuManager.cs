using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine.Networking;
using System;
using UnityEngine.UI;

namespace BMRolling
{

    [System.Serializable]
    public partial class MenuManager : MonoBehaviour
    {

        //public UnityEngine.UI.Text timer;
        //public int timecounter;
        public int totalScore;
        public Text TotalScoreText;
        public GameObject MainMenuHolder;
        public GameObject PlayMenuHolder;
        public GameObject GameOverMenuHolder;
        public GameObject BurgerShopMenuHolder;
        public GameObject StoreMenuHolder;
        public GameObject SettingMenuHolder;
        public GameObject PauseMenu;
        public UnityEngine.UI.Text LastScoreText;
        public UnityEngine.UI.Text BestScoreText;
        public UnityEngine.UI.Text ScoreText, PERKSUMM, TIMESUM, HEALTHSUMM;
        public UnityEngine.UI.Image ReviveCircle;
        public UnityEngine.UI.Text BurgarNumber;
        public UnityEngine.UI.Text FinalScoreText;
        public GameObject HelpFinger;
        public UnityEngine.UI.Text ReviveNumberText;
        public UnityEngine.UI.Image ShieldIGM;
        public UnityEngine.UI.Image TurboIGM;
        public UnityEngine.UI.Text ShieldNumberIGM;
        public UnityEngine.UI.Text TurboNumberIGM;
        public GameObject NewRecord;
        public GameObject NewRecordFX;
        public GameObject StoreSystem;
        public GameObject WinPrizeBTN;
        public GameObject FreeGiftBTN;
        public GameObject SettingTabMenu;
        public GameObject RateUsTabMenu;
        public GameObject RateUsFirstTabMenu;
        public GameObject PopUpTabMenu;
        public GameObject CriditsTabMenu;
        public GameObject ExitTabMenu;
        public GameObject AudioManager;
        public GameObject OtherGamesButton;
        public UnityEngine.UI.Button BurgerReviveBTN;
        public UnityEngine.UI.Button VideoReviveBTN;
        public UnityEngine.UI.Button WinPrizeButton;
        public UnityEngine.UI.Text WinPrizeText;
        public UnityEngine.UI.Text FinalBurger;
        private Animator MainMenuAnimator;
        private Animator PlayMenuAnimator;
        private Animator ReviveMenuAnimator;
        private Animator GameOverMenuAnimator;
        private Animator BurgerShopMenuAnimator;
        private Animator StoreMenuAnimator;
        private Animator SettingMenuAnimator;
        private UnityEngine.UI.Image WhitePage;
        private UnityEngine.UI.Text LoadingText;
        private GameDataManager DataManager;
        private bool CancelRevive;
        private UnityEngine.UI.Text NewRecordText;
        private RectTransform NewRecordTransform;
        private bool NewRecordRegister;
        private bool SettingActive;
        public virtual IEnumerator Start()
        {

            //WhitePage.color.a = 0.0;
            this.InvokeRepeating("ScoreUpdate", 0.5f, 0.5f);
            this.DataManager = new GameDataManager();
            this.LastScoreText.text = "" + GameDataManager.GetData("LastScore");
            this.BestScoreText.text = "" + GameDataManager.GetData("BestScore");
            this.BurgarNumber.text = "" + this.DataManager.GetBurgar();
            this.MainMenuAnimator = this.MainMenuHolder.GetComponent<Animator>();
            this.PlayMenuAnimator = this.PlayMenuHolder.GetComponent<Animator>();
            this.GameOverMenuAnimator = this.GameOverMenuHolder.GetComponent<Animator>();
            this.BurgerShopMenuAnimator = this.BurgerShopMenuHolder.GetComponent<Animator>();
            this.StoreMenuAnimator = this.StoreMenuHolder.GetComponent<Animator>();
            this.SettingMenuAnimator = this.SettingMenuHolder.GetComponent<Animator>();
            this.MainMenuAnimator.Play("idle", -1, 0);
            this.NewRecordText = this.NewRecord.GetComponent<UnityEngine.UI.Text>();
            this.NewRecordTransform = this.NewRecord.GetComponent<RectTransform>();
            //this.WhitePage = GameObject.Find("WhitePage").GetComponent<UnityEngine.UI.Image>();
            //this.LoadingText = GameObject.Find("LoadingText").GetComponent<UnityEngine.UI.Text>();

            StartCoroutine(GetStoreData());

            //if (this.WhitePage.color.a > 0)
            //{
            //    yield return new WaitForSeconds(0.5f);
            //}

            {
                //float _31 = 0f;
                //Color _32 = this.LoadingText.color;
                //_32.a = _31;
                //this.LoadingText.color = _32;
            }
            if (PlayerPrefs.GetInt("GamePlayed") == 3)
            {
                yield return null;
                this.SettingEnter(2);
            }
            if (((PlayerPrefs.GetInt("GamePlayed") == 15) || (PlayerPrefs.GetInt("GamePlayed") == 32)) || (PlayerPrefs.GetInt("GamePlayed") == 60))
            {
                yield return null;
                this.SettingEnter(1);
            }
        }
        //public void Timerfun()
        //{

        //    while (timecounter<0)
        //    {
        //        timecounter--;
        //    }
        //}

        public virtual void ScoreUpdate()
        {
            print("SCORE UPDATE");
            //this.ScoreText.text = "" + GameManager.Score;
            this.ScoreText.text = "" + GameManager.InPlayBurger;
            this.BurgarNumber.text = "" + this.DataManager.GetBurgar();
        }
        public virtual IEnumerator MainMenuGoUp()
        {
            this.MainMenuAnimator.Play("GoUp", -1, 0);
            yield return new WaitForSeconds(1f);
            this.MainMenuHolder.SetActive(false);
        }
        public virtual IEnumerator PlayMenuGoDown()
        {
            yield return new WaitForSeconds(0.5f);
            this.PlayMenuAnimator.Play("GoDown", -1, 0);
            yield return new WaitForSeconds(0.5f);
            this.ShowPuwerUps();
            this.HelpFinger.SetActive(true);
            yield return new WaitForSeconds(3.5f);
            this.HelpFinger.SetActive(false);
        }

        public virtual void ShowPuwerUps()
        {
            this.ShieldNumberIGM.text = "" + GameDataManager.GetData("ShieldNumber");
            this.TurboNumberIGM.text = "" + GameDataManager.GetData("TurboNumber");
            if (GameDataManager.GetData("ShieldNumber") > 0)
            {
                this.ShieldIGM.enabled = true;
                this.ShieldNumberIGM.enabled = true;
                this.StartCoroutine(this.FadeInShield());
            }
            else
            {
                this.ShieldIGM.enabled = false;
                this.ShieldNumberIGM.enabled = false;
            }
            if (GameDataManager.GetData("TurboNumber") > 0)
            {
                this.TurboIGM.enabled = true;
                this.TurboNumberIGM.enabled = true;
                this.StartCoroutine(this.FadeInTurbo());
            }
            else
            {
                this.TurboIGM.enabled = false;
                this.TurboNumberIGM.enabled = false;
            }
        }

        public virtual IEnumerator FadeInShield()
        {
            while (this.ShieldIGM.color.a < 1)
            {

                {
                    float _33 = this.ShieldIGM.color.a + 0.05f;
                    Color _34 = this.ShieldIGM.color;
                    _34.a = _33;
                    this.ShieldIGM.color = _34;
                }

                {
                    float _35 = this.ShieldNumberIGM.color.a + 0.05f;
                    Color _36 = this.ShieldNumberIGM.color;
                    _36.a = _35;
                    this.ShieldNumberIGM.color = _36;
                }
                yield return null;
            }
        }

        public virtual IEnumerator FadeInTurbo()
        {
            while (this.TurboIGM.color.a < 1)
            {

                {
                    float _37 = this.TurboIGM.color.a + 0.05f;
                    Color _38 = this.TurboIGM.color;
                    _38.a = _37;
                    this.TurboIGM.color = _38;
                }

                {
                    float _39 = this.TurboNumberIGM.color.a + 0.05f;
                    Color _40 = this.TurboNumberIGM.color;
                    _40.a = _39;
                    this.TurboNumberIGM.color = _40;
                }
                yield return null;
            }
        }

        public virtual void HidePuwerUps()
        {
            this.ShieldIGM.enabled = false;
            this.ShieldNumberIGM.enabled = false;
            this.TurboIGM.enabled = false;
            this.TurboNumberIGM.enabled = false;
        }

        public virtual void RestartMainMenuAnimate()
        {
            this.MainMenuAnimator.Play("idle", -1, 0);
        }

        public virtual void Pause()
        {
            Time.timeScale = 0;
            GameManager.InMenu = true;
            this.PauseMenu.SetActive(true);
            this.AudioManager.SendMessage("ButtonClick");
        }

        public virtual IEnumerator Resume()
        {
            Time.timeScale = 1;
            this.PauseMenu.SetActive(false);
            yield return null;
            GameManager.InMenu = false;
            this.AudioManager.SendMessage("ButtonClick");
        }

        public virtual IEnumerator Restart()
        {
            Time.timeScale = 1;

            {
                float _41 = //WhitePage.color.a = 1.0;
                1f;
                Color _42 = this.LoadingText.color;
                _42.a = _41;
                this.LoadingText.color = _42;
            }
            this.AudioManager.SendMessage("ButtonClick");
            yield return new WaitForSeconds(0.5f);
            SceneManager.LoadScene(1);
            //SkillzCrossPlatform.ReturnToSkillz();

        }
        public GameObject mysubmitbutton;
        //private void OnSuccess()
        //{
        //    mysubmitbutton.SetActive(true);
        //    //kamranskillz

        //    Debug.Log("my Success Call");
        //}
        //private void OnFailure(string temp)
        //{
        //    SkillzCrossPlatform.DisplayTournamentResultsWithScore(totalScore);
        //}
        public virtual IEnumerator GameOver()
        {
            print("gameover screen");
            this.HidePuwerUps();
            GameManager.InGameOver = true;
            this.GameOverMenuHolder.SetActive(true);


            this.FinalScoreText.text = "" + GameManager.Score;
            print("burger score");
            if (GameManager.instance.endmatch == true)
            {
                Timer.instance.myinttimer = 0;
                GameManager.instance.scorehealthcoun = 0;
            }
            this.FinalBurger.text = "" + GameManager.InPlayBurger;
            this.PERKSUMM.text = MyPlayer.instance.perk.ToString();
            this.TIMESUM.text = "" + Timer.instance.myinttimer;
            this.HEALTHSUMM.text = "" + GameManager.instance.scorehealthcoun * 5;
            totalScore = GameManager.instance.scorehealthcoun * 5 + Timer.instance.myinttimer + MyPlayer.instance.perk + GameManager.InPlayBurger;
            TotalScoreText.text = totalScore.ToString();


            //SkillzCrossPlatform.SubmitScore(totalScore, OnSuccess, OnFailure);
            if (GameManager.ReviveNumber < 2600)
            {
                this.ReviveNumberText.text = "" + GameManager.ReviveNumber;
            }
            else
            {
                this.BurgerReviveBTN.interactable = false;
                this.ReviveNumberText.text = "";
            }
            if (GameManager.ReviveVideo > 6)
            {
                this.VideoReviveBTN.interactable = false;
            }
            if (this.DataManager.GetBurgar() < 100)
            {
                this.WinPrizeButton.interactable = false;
                int BNR = 100 - this.DataManager.GetBurgar();
                this.WinPrizeText.text = ("" + BNR) + " BURGER \nTO GO";
            }
            else
            {
                this.WinPrizeButton.interactable = true;
                this.WinPrizeText.text = "WIN A PRIZE";
            }
            if (this.CalculateGiftTime() == 0)
            {
                this.WinPrizeBTN.SetActive(true);
                this.FreeGiftBTN.SetActive(false);
            }
            else
            {
                this.WinPrizeBTN.SetActive(false);
                this.FreeGiftBTN.SetActive(true);
            }
            this.PlayMenuAnimator.Play("GoUp", -1, 0);
            yield return new WaitForSeconds(0.5f);
            this.GameOverMenuAnimator.Play("Come", -1, 0);
            yield return new WaitForSeconds(0.5f);
            this.AudioManager.SendMessage("GameOver");
            yield return new WaitForSeconds(0.5f);
            if (GameManager.Score > GameDataManager.GetData("BestScore"))
            {
                this.NewRecordRegister = true;
            }
            this.SaveGameData();
            while ((this.ReviveCircle.fillAmount < 1) && !this.CancelRevive)
            {
                this.ReviveCircle.fillAmount = this.ReviveCircle.fillAmount + (0.21f * Time.deltaTime); //0.004 
                yield return null;
            }
            yield return new WaitForSeconds(0.1f);
            if (this.CancelRevive)
            {
                this.CancelRevive = false;
                this.ReviveCircle.fillAmount = 0;
                yield break;
            }
            if (this.NewRecordRegister)
            {
                this.StartCoroutine(this.ShowNewRecord());
                this.NewRecordRegister = false;
            }
            this.GameOverMenuAnimator.Play("Come2", -1, 0);
        }

        public virtual int CalculateGiftTime()
        {
            string LT = PlayerPrefs.GetString("LastTimePlayed");
            System.DateTime Last = System.DateTime.Parse(LT);
            System.DateTime Current = System.DateTime.Now;
            System.TimeSpan Diff = Current.Subtract(Last).Duration();
            if (PlayerPrefs.GetInt("CharacterGift") < 4)
            {
                if (PlayerPrefs.GetInt("CharacterGift") == 0)
                {
                    return 1; // Free Gift Time
                }
                if (PlayerPrefs.GetInt("CharacterGift") == 1)
                {
                    if (Diff.TotalMinutes > 2)
                    {
                        return 1; // Free Gift Time
                    }
                    else
                    {
                        return 0;
                    }
                }
                if (PlayerPrefs.GetInt("CharacterGift") == 2)
                {
                    if (Diff.TotalMinutes > 5)
                    {
                        return 1; // Free Gift Time
                    }
                    else
                    {
                        return 0;
                    }
                }
                if (PlayerPrefs.GetInt("CharacterGift") == 3)
                {
                    if (Diff.TotalMinutes > 15)
                    {
                        return 1; // Free Gift Time
                    }
                    else
                    {
                        return 0;
                    }
                }
            }
            else
            {
                if (Diff.TotalHours > 6)
                {
                    return 1; // Free Gift Time
                }
                else
                {
                    return 0;
                }
            }
            return 0;
        }

        public virtual void ResetGiftButtons()
        {
            if (this.CalculateGiftTime() == 0)
            {
                this.WinPrizeBTN.SetActive(true);
                this.FreeGiftBTN.SetActive(false);
            }
            else
            {
                this.WinPrizeBTN.SetActive(false);
                this.FreeGiftBTN.SetActive(true);
            }
        }

        public virtual IEnumerator ShowNewRecord()
        {

            {
                int _43 = 1;
                Color _44 = this.NewRecordText.color;
                _44.a = _43;
                this.NewRecordText.color = _44;
            }

            {
                float _45 = -1.5f;
                Vector3 _46 = this.NewRecordTransform.localScale;
                _46.x = _45;
                this.NewRecordTransform.localScale = _46;
            }
            while (this.NewRecordTransform.localScale.x < 1f)
            {

                {
                    float _47 = this.NewRecordTransform.localScale.x + 0.15f;
                    Vector3 _48 = this.NewRecordTransform.localScale;
                    _48.x = _47;
                    this.NewRecordTransform.localScale = _48;
                }
                yield return null;
            }

            {
                float _49 = 1f;
                Vector3 _50 = this.NewRecordTransform.localScale;
                _50.x = _49;
                this.NewRecordTransform.localScale = _50;
            }
            this.NewRecordFX.SetActive(true);
        }

        public virtual void SaveGameData()
        {
            this.DataManager.SetData("LastScore", GameManager.Score);
            if (GameManager.Score > GameDataManager.GetData("BestScore"))
            {
                this.DataManager.SetData("BestScore", GameManager.Score);
            }
            //GameObject.Find("CBSocial").SendMessage("PostLeaderboardScore", GameDataManager.GetData("BestScore"));
        }

        public void OtherGames()
        {
            if (Application.platform == RuntimePlatform.Android)
            {
                Application.OpenURL(storeData.android);
            }
            else
            {
                Application.OpenURL(storeData.ios);
            }
        }

        public static StoreData storeData = new StoreData();
        private IEnumerator GetStoreData()
        {
            storeData.android = "https://play.google.com/store/apps/details?id=com.playpax.savingbubbleman";
            storeData.ios = "http://itunes.apple.com/app/id1067089977";

            if (PlayerPrefs.GetInt("GamePlayed") > 2 && Application.platform != RuntimePlatform.WindowsEditor && Application.platform != RuntimePlatform.OSXEditor)
            {
                OtherGamesButton.SetActive(true);
            }
            else
            {
                OtherGamesButton.SetActive(false);
            }

            yield return new WaitForSeconds(1.0f);

            using UnityWebRequest request = UnityWebRequest.Get("https://drive.google.com/uc?export=download&id=1IW6qPWdalSIqepV00qZoF-6kSmWJ-2G_");
            request.timeout = 20;
            yield return request.SendWebRequest();
            if (request.result == UnityWebRequest.Result.Success)
            {
                storeData = JsonUtility.FromJson<StoreData>(request.downloadHandler.text);
            }
            else
            {

            }
        }

        public virtual IEnumerator Revive()
        {
            this.AudioManager.SendMessage("Revive");
            this.CancelRevive = true;
            GameManager.InGameOver = false;
            //this.GameOverMenuAnimator.Play("Out", -1, 0);
            this.ReviveCircle.fillAmount = 0;
            yield return new WaitForSeconds(0.7f);
            this.PlayMenuAnimator.Play("GoDown", -1, 0);
            this.ShowPuwerUps();
            this.GameOverMenuHolder.SetActive(false);
        }

        public virtual void BurgerShopEnter()
        {
            this.BurgerShopMenuHolder.SetActive(true);
            this.BurgerShopMenuAnimator.Play("Come", -1, 0);
            this.AudioManager.SendMessage("ButtonClick");
        }

        public virtual void BurgerShopExit()
        {
            this.BurgerShopMenuAnimator.Play("Out", -1, 0);
            this.StartCoroutine(this.BurgerShopClose());
            this.AudioManager.SendMessage("ButtonClick");
        }

        public virtual IEnumerator BurgerShopClose()
        {
            yield return new WaitForSeconds(0.3f);
            this.BurgerShopMenuHolder.SetActive(false);
        }

        public virtual void StoreEnter()
        {
            this.StoreMenuHolder.SetActive(true);
            this.StoreSystem.SendMessage("StoreOpen");
            this.StoreMenuAnimator.Play("StoreCome", -1, 0);
            this.AudioManager.SendMessage("ButtonClick");
        }

        public virtual void StoreExit()
        {
            this.StoreMenuAnimator.Play("StoreOut", -1, 0);
            this.StoreSystem.SendMessage("StoreClose");
            this.StartCoroutine(this.StoreClose());
            this.AudioManager.SendMessage("ButtonClick");
        }

        public virtual IEnumerator StoreClose()
        {
            yield return new WaitForSeconds(0.3f);
            this.StoreMenuHolder.SetActive(false);
        }

        public virtual void SettingEnter(int type)
        {
            if (this.SettingActive)
            {
                return;
            }
            this.SettingActive = true;
            this.AudioManager.SendMessage("ButtonClick");
            if (type == 0)
            {
                this.SettingTabMenu.SetActive(true);
                this.RateUsTabMenu.SetActive(false);
                this.RateUsFirstTabMenu.SetActive(false);
                this.PopUpTabMenu.SetActive(false);
                this.CriditsTabMenu.SetActive(false);
                this.ExitTabMenu.SetActive(false);
            }
            if (type == 1)
            {
                this.RateUsTabMenu.SetActive(true);
                this.SettingTabMenu.SetActive(false);
                this.RateUsFirstTabMenu.SetActive(false);
                this.PopUpTabMenu.SetActive(false);
                this.CriditsTabMenu.SetActive(false);
                this.ExitTabMenu.SetActive(false);
            }
            if (type == 2)
            {
                this.RateUsFirstTabMenu.SetActive(true);
                this.RateUsTabMenu.SetActive(false);
                this.SettingTabMenu.SetActive(false);
                this.PopUpTabMenu.SetActive(false);
                this.CriditsTabMenu.SetActive(false);
                this.ExitTabMenu.SetActive(false);
            }
            if (type == 3)
            {
                this.PopUpTabMenu.SetActive(true);
                this.RateUsFirstTabMenu.SetActive(false);
                this.RateUsTabMenu.SetActive(false);
                this.SettingTabMenu.SetActive(false);
                this.CriditsTabMenu.SetActive(false);
                this.ExitTabMenu.SetActive(false);
            }
            if (type == 4)
            {
                this.ExitTabMenu.SetActive(true);
                this.PopUpTabMenu.SetActive(false);
                this.RateUsFirstTabMenu.SetActive(false);
                this.RateUsTabMenu.SetActive(false);
                this.SettingTabMenu.SetActive(false);
                this.CriditsTabMenu.SetActive(false);
            }
            this.SettingMenuHolder.SetActive(true);
            this.SettingMenuAnimator.Play("Come", -1, 0);
        }

        public virtual void SettingExit()
        {
            this.AudioManager.SendMessage("ButtonClick");
            this.SettingMenuAnimator.Play("Out", -1, 0);
            this.StartCoroutine(this.SettingClose());
        }

        public virtual IEnumerator SettingClose()
        {
            yield return new WaitForSeconds(0.3f);
            this.SettingMenuHolder.SetActive(false);
            this.SettingActive = false;
        }

        public virtual void GoToRate()
        {
            this.RateUsTabMenu.SetActive(true);
            this.SettingTabMenu.SetActive(false);
            this.RateUsFirstTabMenu.SetActive(false);
            this.PopUpTabMenu.SetActive(false);
            this.CriditsTabMenu.SetActive(false);
            this.ExitTabMenu.SetActive(false);
        }

        public virtual void GoToCridits()
        {
            this.CriditsTabMenu.SetActive(true);
            this.RateUsTabMenu.SetActive(false);
            this.SettingTabMenu.SetActive(false);
            this.RateUsFirstTabMenu.SetActive(false);
            this.PopUpTabMenu.SetActive(false);
            this.ExitTabMenu.SetActive(false);
        }

        public virtual void GoToExit()
        {
            this.ExitTabMenu.SetActive(true);
            this.CriditsTabMenu.SetActive(false);
            this.RateUsTabMenu.SetActive(false);
            this.SettingTabMenu.SetActive(false);
            this.RateUsFirstTabMenu.SetActive(false);
            this.PopUpTabMenu.SetActive(false);
        }

        public virtual void ExitGame()
        {
            Application.Quit();
        }

        public virtual void RateUs()
        {
            this.AudioManager.SendMessage("ButtonClick");
            GameObject.Find("GameManager").SendMessage("OpenURL", 0);
            this.SettingExit();
        }
    }
}

namespace BMRolling
{
    [Serializable]
    public class StoreData
    {
        public string android;
        public string ios;
    }
}