using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class StoreSystem : MonoBehaviour
    {
        public GameObject[] StoreItems;
        public GameObject _Player;
        public GameObject MenuManager;
        //------ Powerup
        public UnityEngine.UI.Text ShieldNumberText;
        public UnityEngine.UI.Text TurboNumberText;
        public UnityEngine.UI.Text MagnetNumberText;
        //------ Player
        public RectTransform PlayersMenuRect;
        public RectTransform[] Players;
        public UnityEngine.UI.Text PlayersNamesText;
        public string[] PlayersNames;
        public int[] PlayersBuyPrice;
        public GameObject PlayersBuyBTN;
        public GameObject PlayerSelected;
        public Material NormalMaterial;
        public Material GrayMaterial;
        public UnityEngine.UI.Text PlayersPrice;
        //------ Burger
        //------ Gift
        public GameObject GiftShopMenu;
        public RectTransform GiftNames;
        public UnityEngine.UI.Image CharacterIcon;
        public RectTransform CharacterRect;
        public Sprite[] CharacterTexture;
        public GameObject GiftBTN;
        public GameObject FreeGiftBTN;
        public UnityEngine.UI.Text GiftShopText;
        public UnityEngine.UI.Text BurgarGiftText;
        public GameObject BackBTN;
        public UnityEngine.UI.Text CharacterNameText;
        //-------- Upgrade
        public UnityEngine.UI.Image[] ShieldLine;
        public UnityEngine.UI.Image[] TurboLine;
        public UnityEngine.UI.Image[] MagnetLine;
        public GameObject ShieldUpBTN;
        public GameObject TurboUpBTN;
        public GameObject MagnetUpBTN;
        public UnityEngine.UI.Text[] UpgradePrices;
        public int[] UpgradePricesAmount;
        public GameObject AudioManager;
        public GameObject ModeManager;
        public GameObject ButtonAlarm;
        public RectTransform ShopBtnRect;
        public RectTransform EarnBurgerBtnRect;
        public UnityEngine.UI.Image RandomCharacterBtn;
        public Sprite[] RandomCharacterBtnTexture;
        public UnityEngine.UI.Text RandomText;
        //-----------------------------------------------------
        private GameDataManager DataManager;
        private Animator GiftShopAnimator;
        private bool BuyPlayerMenu;
        private float scrollViewVector;
        private float PlayerMenuPos;
        private int PlayerSelectNumber;
        private int PlayerSelectNumberOld;
        private float PlayerControllerPos;
        private bool SlotMachinOn;
        private bool ShotButtonAlarm;
        private bool EarnBurgerButtonAlarm;
        //--------------------- General -----------------------
        public virtual IEnumerator Start()
        {
            this.DataManager = new GameDataManager();
            this.ShieldNumberText.text = ("" + GameDataManager.GetData("ShieldNumber")) + "/20";
            this.TurboNumberText.text = ("" + GameDataManager.GetData("TurboNumber")) + "/20";
            this.MagnetNumberText.text = ("" + GameDataManager.GetData("MagnetNumber")) + "/1";
            this.GiftShopAnimator = this.GiftShopMenu.GetComponent<Animator>();
            this.RefreshPlayer();
            this.RefreshMaterial();
            //For Test
            //DataManager.SetData("ShieldUpgrade",0);
            //DataManager.SetData("TurboUpgrade",0);
            //DataManager.SetData("MagnetUpgrade",0);
            //PlayerPrefs.SetInt("GamePlayed",0);
            this.RefreshUpgrade(0);
            this.RefreshUpgrade(1);
            this.RefreshUpgrade(2);
            if (PlayerPrefs.GetInt("GamePlayed") != 0)
            {
                if (this.CalculateGiftTime() == 1)
                {
                    this.ButtonAlarm.SetActive(true);
                }
            }
            if ((PlayerPrefs.GetInt("GamePlayed") > 1) && (PlayerPrefs.GetInt("StoreOpen") == 0))
            {
                this.ShotButtonAlarm = true;
            }
            if (((PlayerPrefs.GetInt("GamePlayed") == 4) || (PlayerPrefs.GetInt("GamePlayed") == 13)) || (PlayerPrefs.GetInt("GamePlayed") == 41))
            {
                this.EarnBurgerButtonAlarm = true;
                yield return new WaitForSeconds(10);
                this.EarnBurgerButtonAlarm = false;
            }
            if (PlayerPrefs.GetInt("RandomCharacter") == 1)
            {
                this.StartCoroutine(this.SetRandomCharacter());
            }
            if (PlayerPrefs.GetInt("RandomCharacter") == 1)
            {
                this.RandomCharacterBtn.sprite = this.RandomCharacterBtnTexture[1];
                this.RandomText.text = "ON";
            }
            else
            {
                this.RandomCharacterBtn.sprite = this.RandomCharacterBtnTexture[0];
                this.RandomText.text = "OFF";
            }
        }

        public virtual IEnumerator SetRandomCharacter()
        {
            if (PlayerPrefs.GetInt("GetGift") == 1)
            {
                PlayerPrefs.SetInt("GetGift", 0);
                yield break;
            }
            yield return new WaitForSeconds(0.03f);
            int[] ChNumbers = null;
            ChNumbers = new int[37];
            int ChAvalable = 0;
            int i = 1;
            while (i < 38)
            {
                if (PlayerPrefs.GetInt("ch_sbm_" + i) != 0)
                {
                    ChNumbers[ChAvalable] = i;
                    ChAvalable = ChAvalable + 1;
                }
                i++;
            }
            int ChTarget = Random.Range(0, ChAvalable);
            this.PlayerSelectNumber = ChNumbers[ChTarget];
            this.SelectPlayer();
            this.RefreshPlayer();
            yield return new WaitForSeconds(0.3f);
            this.RefreshMaterial();
        }

        public virtual void Restore() //SoomlaStore.RestoreTransactions();
        {
        }

        public virtual void StoreOpen()
        {
            PlayerPrefs.SetInt("StoreOpen", 1);
            this.ShowPlayer();
            this.ShotButtonAlarm = false;

            {
                int _51 = 95;
                Vector2 _52 = this.ShopBtnRect.sizeDelta;
                _52.x = _51;
                this.ShopBtnRect.sizeDelta = _52;
            }

            {
                int _53 = 95;
                Vector2 _54 = this.ShopBtnRect.sizeDelta;
                _54.y = _53;
                this.ShopBtnRect.sizeDelta = _54;
            }
        }

        public virtual IEnumerator StoreClose()
        {
            this.PlayerControllerPos = 0;
            yield return new WaitForSeconds(0.3f);
            this.BuyPlayerMenu = false;
        }

        public virtual void Update()
        {
            if (GameManager.Enable)
            {
                if (Input.GetKeyDown(KeyCode.Escape))
                {
                    if (!GameManager.InGameOver)
                    {
                        this.MenuManager.SendMessage("Pause");
                    }
                }
            }
            else
            {
                if (Input.GetKeyDown(KeyCode.Escape))
                {
                    this.MenuManager.SendMessage("SettingEnter", 4);
                }
            }
            if (this.ShotButtonAlarm)
            {

                {
                    float _55 = 95 + Mathf.PingPong(Time.time * 28, 8);
                    Vector2 _56 = this.ShopBtnRect.sizeDelta;
                    _56.x = _55;
                    this.ShopBtnRect.sizeDelta = _56;
                }

                {
                    float _57 = 95 + Mathf.PingPong(Time.time * 28, 8);
                    Vector2 _58 = this.ShopBtnRect.sizeDelta;
                    _58.y = _57;
                    this.ShopBtnRect.sizeDelta = _58;
                }
            }
            if (this.EarnBurgerButtonAlarm)
            {

                {
                    float _59 = 95 + Mathf.PingPong(Time.time * 28, 7);
                    Vector2 _60 = this.EarnBurgerBtnRect.sizeDelta;
                    _60.x = _59;
                    this.EarnBurgerBtnRect.sizeDelta = _60;
                }

                {
                    float _61 = 95 + Mathf.PingPong(Time.time * 28, 7);
                    Vector2 _62 = this.EarnBurgerBtnRect.sizeDelta;
                    _62.y = _61;
                    this.EarnBurgerBtnRect.sizeDelta = _62;
                }
            }
            if (this.BuyPlayerMenu)
            {
                if (Application.platform != RuntimePlatform.OSXEditor)
                {
                    if (Input.touchCount > 0)
                    {
                        Touch touch = Input.touches[0];
                        if (touch.phase == TouchPhase.Moved)
                        {
                            //PlayerMenuPos = (-touch.deltaPosition.x/touch.deltaTime) * 3;
                            this.PlayerMenuPos = -touch.deltaPosition.x * (Time.deltaTime / touch.deltaTime);
                        }
                    }
                    else
                    {
                        //PlayerMenuPos = -touch.deltaPosition.x * 3;
                        //t.deltaPosition * (Time.deltaTime / t.deltaTime));
                        //touchSpeed = touch.deltaPosition.magnitude / touch.deltaTime;
                        this.PlayerMenuPos = Mathf.Lerp(this.PlayerMenuPos, 0, Time.deltaTime * 6f);
                    }
                }
                else
                {
                    if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.RightArrow))
                    {
                        this.PlayerMenuPos = ((Input.GetAxis("Horizontal") * 7) * Time.deltaTime) * 60;
                    }
                    else
                    {
                        this.PlayerMenuPos = Mathf.Lerp(this.PlayerMenuPos, 0, Time.deltaTime * 2f);
                    }
                }
                //scrollViewVector = PlayersMenuRect.anchoredPosition.x / 200;
                this.scrollViewVector = this.PlayerControllerPos / 200;
                this.PlayerSelectNumber = (int)(Mathf.Round(Mathf.Abs(this.scrollViewVector)) % 38);
                if (this.PlayerSelectNumber != this.PlayerSelectNumberOld)
                {
                    this.PlayerSelectNumberOld = this.PlayerSelectNumber;
                    this.ShowPlayerIcon(this.PlayerSelectNumber);
                }
                if (Application.platform != RuntimePlatform.OSXEditor)
                {
                    if (((this.PlayerMenuPos < -2) || (this.PlayerMenuPos > 2)) || (Input.touchCount > 0))
                    {
                        this.PlayerControllerPos = this.PlayerControllerPos - this.PlayerMenuPos;
                    }
                    else
                    {
                        this.PlayerControllerPos = this.PlayerSelectNumber * -200;
                    }
                }
                else
                {
                    if ((this.PlayerMenuPos < -2) || (this.PlayerMenuPos > 2))
                    {
                        this.PlayerControllerPos = this.PlayerControllerPos - this.PlayerMenuPos;
                    }
                    else
                    {
                        this.PlayerControllerPos = this.PlayerSelectNumber * -200;
                    }
                }
                if (this.PlayerControllerPos < (37 * -200))
                {
                    this.PlayerControllerPos = 37 * -200;
                }
                if (this.PlayerControllerPos > 0)
                {
                    this.PlayerControllerPos = 0;
                }

                {
                    float _63 = Mathf.Lerp(this.PlayersMenuRect.anchoredPosition.x, this.PlayerControllerPos, Time.deltaTime * 10f);
                    Vector2 _64 = this.PlayersMenuRect.anchoredPosition;
                    _64.x = _63;
                    this.PlayersMenuRect.anchoredPosition = _64;
                }
            }
        }

        public virtual void RandomCharacter()
        {
            if (PlayerPrefs.GetInt("RandomCharacter") == 1)
            {
                this.RandomCharacterBtn.sprite = this.RandomCharacterBtnTexture[0];
                PlayerPrefs.SetInt("RandomCharacter", 0);
                this.RandomText.text = "OFF";
            }
            else
            {
                this.RandomCharacterBtn.sprite = this.RandomCharacterBtnTexture[1];
                PlayerPrefs.SetInt("RandomCharacter", 1);
                this.RandomText.text = "ON";
            }
        }

        //------------------ Store Items --------------------
        public virtual void ShowPowerups()
        {
            this.StoreItems[1].SetActive(false);
            this.StoreItems[2].SetActive(false);
            this.StoreItems[0].SetActive(true);
            this.BuyPlayerMenu = false;
            this.AudioManager.SendMessage("ButtonClick");
        }

        public virtual void ShowPlayer()
        {
            this.StoreItems[0].SetActive(false);
            this.StoreItems[2].SetActive(false);
            this.StoreItems[1].SetActive(true);
            this.PlayerSelectNumber = GameDataManager.GetData("PlayerSelect");
            this.PlayerControllerPos = this.PlayerSelectNumber * -200;
            this.ShowPlayerIcon(this.PlayerSelectNumber);
            this.AudioManager.SendMessage("ButtonClick");
            this.StartCoroutine(this.ShowPlayerReset());
        }

        public virtual IEnumerator ShowPlayerReset()
        {
            yield return new WaitForSeconds(0.22f);
            this.BuyPlayerMenu = true;
        }

        public virtual void ShowBurger()
        {
            this.StoreItems[0].SetActive(false);
            this.StoreItems[1].SetActive(false);
            this.StoreItems[2].SetActive(true);
            this.BuyPlayerMenu = false;
            this.AudioManager.SendMessage("ButtonClick");
        }

        // ------------------ Upgrade --------------------
        public virtual void Upgrade(int type)
        {
            if (type == 0)
            {
                if ((this.DataManager.GetBurgar() >= this.UpgradePricesAmount[GameDataManager.GetData("ShieldUpgrade")]) && (GameDataManager.GetData("ShieldUpgrade") < 4))
                {
                    this.DataManager.TakeBurgar(this.UpgradePricesAmount[GameDataManager.GetData("ShieldUpgrade")]);
                    this.DataManager.SetData("ShieldUpgrade", GameDataManager.GetData("ShieldUpgrade") + 1);
                    this.RefreshUpgrade(0);
                    this.AudioManager.SendMessage("AddPowerup");
                }
                else
                {
                    this.AudioManager.SendMessage("NoMoney");
                    if (this.DataManager.GetBurgar() < this.UpgradePricesAmount[GameDataManager.GetData("ShieldUpgrade")])
                    {
                        this.MenuManager.SendMessage("BurgerShopEnter");
                    }
                }
            }
            if (type == 1)
            {
                if ((this.DataManager.GetBurgar() >= this.UpgradePricesAmount[GameDataManager.GetData("TurboUpgrade")]) && (GameDataManager.GetData("TurboUpgrade") < 4))
                {
                    this.DataManager.TakeBurgar(this.UpgradePricesAmount[GameDataManager.GetData("TurboUpgrade")]);
                    this.DataManager.SetData("TurboUpgrade", GameDataManager.GetData("TurboUpgrade") + 1);
                    this.RefreshUpgrade(1);
                    this.AudioManager.SendMessage("AddPowerup");
                }
                else
                {
                    this.AudioManager.SendMessage("NoMoney");
                    if (this.DataManager.GetBurgar() < this.UpgradePricesAmount[GameDataManager.GetData("TurboUpgrade")])
                    {
                        this.MenuManager.SendMessage("BurgerShopEnter");
                    }
                }
            }
            if (type == 2)
            {
                if ((this.DataManager.GetBurgar() >= this.UpgradePricesAmount[GameDataManager.GetData("MagnetUpgrade")]) && (GameDataManager.GetData("MagnetUpgrade") < 4))
                {
                    this.DataManager.TakeBurgar(this.UpgradePricesAmount[GameDataManager.GetData("MagnetUpgrade")]);
                    this.DataManager.SetData("MagnetUpgrade", GameDataManager.GetData("MagnetUpgrade") + 1);
                    this.RefreshUpgrade(2);
                    this._Player.SendMessage("SetMagnet");
                    this.AudioManager.SendMessage("AddPowerup");
                }
                else
                {
                    this.AudioManager.SendMessage("NoMoney");
                    if (this.DataManager.GetBurgar() < this.UpgradePricesAmount[GameDataManager.GetData("MagnetUpgrade")])
                    {
                        this.MenuManager.SendMessage("BurgerShopEnter");
                    }
                }
            }
        }

        public virtual void RefreshUpgrade(int type)
        {
            if (type == 0)
            {
                int i = 0;
                while (i < 4)
                {
                    if (i < GameDataManager.GetData("ShieldUpgrade"))
                    {
                        this.ShieldLine[i].color = new Color(1, 0.39f, 0, 1);
                    }
                    else
                    {
                        this.ShieldLine[i].color = Color.white;
                    }
                    i++;
                }
                if (GameDataManager.GetData("ShieldUpgrade") > 3)
                {
                    this.ShieldUpBTN.SetActive(false);
                }
                else
                {
                    this.ShieldUpBTN.SetActive(true);
                }
                this.UpgradePrices[0].text = "" + this.UpgradePricesAmount[GameDataManager.GetData("ShieldUpgrade")];
            }
            if (type == 1)
            {
                int j = 0;
                while (j < 4)
                {
                    if (j < GameDataManager.GetData("TurboUpgrade"))
                    {
                        this.TurboLine[j].color = new Color(1, 0.39f, 0, 1);
                    }
                    else
                    {
                        this.TurboLine[j].color = Color.white;
                    }
                    j++;
                }
                if (GameDataManager.GetData("TurboUpgrade") > 3)
                {
                    this.TurboUpBTN.SetActive(false);
                }
                else
                {
                    this.TurboUpBTN.SetActive(true);
                }
                this.UpgradePrices[1].text = "" + this.UpgradePricesAmount[GameDataManager.GetData("TurboUpgrade")];
            }
            if (type == 2)
            {
                int s = 0;
                while (s < 4)
                {
                    if (s < GameDataManager.GetData("MagnetUpgrade"))
                    {
                        this.MagnetLine[s].color = new Color(1, 0.39f, 0, 1);
                    }
                    else
                    {
                        this.MagnetLine[s].color = Color.white;
                    }
                    s++;
                }
                if (GameDataManager.GetData("MagnetUpgrade") > 3)
                {
                    this.MagnetUpBTN.SetActive(false);
                }
                else
                {
                    this.MagnetUpBTN.SetActive(true);
                }
                this.UpgradePrices[2].text = "" + this.UpgradePricesAmount[GameDataManager.GetData("MagnetUpgrade")];
            }
        }

        //------------------ Powerups --------------------
        public virtual void AddShield()
        {
            //if ((this.DataManager.GetBurgar() >= 50) && (GameDataManager.GetData("ShieldNumber") < 20))
            {
                this.DataManager.TakeBurgar(50);
                this.DataManager.SetData("ShieldNumber", GameDataManager.GetData("ShieldNumber") + 1);
                this.AudioManager.SendMessage("AddPowerup");
            }
            //else
            //{
            //    this.AudioManager.SendMessage("NoMoney");
            //    if (this.DataManager.GetBurgar() < 50)
            //    {
            //        this.MenuManager.SendMessage("BurgerShopEnter");
            //    }
            //}
            this.ShieldNumberText.text = ("" + GameDataManager.GetData("ShieldNumber")) + "/20";
        }

        public virtual void AddTurbo()
        {
            // if ((this.DataManager.GetBurgar() >= 75) && (GameDataManager.GetData("TurboNumber") < 20))
            {
                this.DataManager.TakeBurgar(75);
                this.DataManager.SetData("TurboNumber", GameDataManager.GetData("TurboNumber") + 1);
                this.AudioManager.SendMessage("AddPowerup");
            }
            ////  else
            //  {
            //      this.AudioManager.SendMessage("NoMoney");
            //      if (this.DataManager.GetBurgar() < 75)
            //      {
            //          this.MenuManager.SendMessage("BurgerShopEnter");
            //      }
            //  }
            this.TurboNumberText.text = ("" + GameDataManager.GetData("TurboNumber")) + "/20";
        }

        public virtual void AddMagnet()
        {
            //if ((this.DataManager.GetBurgar() >= 500) && (GameDataManager.GetData("MagnetNumber") < 1))
            {
                this.DataManager.TakeBurgar(500);
                this.DataManager.SetData("MagnetNumber", GameDataManager.GetData("MagnetNumber") + 1);
                this._Player.SendMessage("SetMagnet");
                this.AudioManager.SendMessage("AddPowerup");
            }
            //else
            //{
            //    this.AudioManager.SendMessage("NoMoney");
            //    if (this.DataManager.GetBurgar() < 500)
            //    {
            //        this.MenuManager.SendMessage("BurgerShopEnter");
            //    }
            //}
            this.MagnetNumberText.text = ("" + GameDataManager.GetData("MagnetNumber")) + "/1";
        }

        //------------------- Player- --------------------
        public virtual void ShowPlayerIcon(int type)
        {
            int i = 0;
            while (i < this.Players.Length)
            {
                this.Players[i].sizeDelta = new Vector2(180, 180);
                i++;
            }
            this.Players[type].sizeDelta = new Vector2(250, 250);
            this.RefreshPlayer();
        }

        public virtual void RefreshPlayer()
        {
            this.PlayersNamesText.text = this.PlayersNames[this.PlayerSelectNumber];
            this.PlayerSelected.SetActive(false);
            this.PlayersPrice.text = "" + this.PlayersBuyPrice[this.PlayerSelectNumber];
            if (this.PlayerSelectNumber == 0)
            {
                this.PlayersBuyBTN.SetActive(false);
                if (GameDataManager.GetData("PlayerSelect") == 0)
                {
                    this.PlayerSelected.SetActive(false);
                }
                else
                {
                    this.PlayerSelected.SetActive(true);
                }
            }
            else
            {
                if (PlayerPrefs.GetInt("ch_sbm_" + this.PlayerSelectNumber) > 0)
                {
                    this.PlayersBuyBTN.SetActive(false);
                    if (GameDataManager.GetData("PlayerSelect") == this.PlayerSelectNumber)
                    {
                        this.PlayerSelected.SetActive(false);
                    }
                    else
                    {
                        this.PlayerSelected.SetActive(true);
                    }
                }
                else
                {
                    this.PlayersBuyBTN.SetActive(true);
                }
            }
        }

        public virtual void RefreshMaterial()
        {
            // Refresh Material
            int i = 1;
            while (i < this.Players.Length)
            {
                if (PlayerPrefs.GetInt("ch_sbm_" + i) > 0)
                {
                    ((UnityEngine.UI.Image)this.Players[i].GetComponent(typeof(UnityEngine.UI.Image))).material = this.NormalMaterial;
                    if (i > 34)
                    {
                        ((UnityEngine.UI.Image)this.Players[i].GetComponent(typeof(UnityEngine.UI.Image))).color = new Color(1, 1, 1, 1);
                    }
                }
                else
                {
                    if (i > 34)
                    {
                        ((UnityEngine.UI.Image)this.Players[i].GetComponent(typeof(UnityEngine.UI.Image))).color = new Color(0, 0, 0, 1);
                    }
                    else
                    {
                        ((UnityEngine.UI.Image)this.Players[i].GetComponent(typeof(UnityEngine.UI.Image))).material = this.GrayMaterial;
                    }
                }
                i++;
            }
        }

        public virtual void SelectPlayer()
        {
            if ((this.PlayerSelectNumber == 22) || (this.PlayerSelectNumber == 30))
            {
                this.AudioManager.SendMessage("JhonCena");
            }
            else
            {
                this.AudioManager.SendMessage("AddPowerup");
            }
            this.DataManager.SetData("PlayerSelect", this.PlayerSelectNumber);
            this.RefreshPlayer();
            if (!GameManager.InGameOver)
            {
                this._Player.SendMessage("CharacterSelect");
                this.MenuManager.SendMessage("RestartMainMenuAnimate");
                this.ModeManager.SendMessage("SetMode");
            }
            else
            {
                this.StartCoroutine(this.RestartMode());
            }
        }

        public virtual IEnumerator RestartMode()
        {
            yield return new WaitForSeconds(2.3f);
            GameObject.Find("GameManager").SendMessage("Restart");
        }

        public virtual void BuyPlayer()
        {
            this.AudioManager.SendMessage("AddPowerup");
            this.BuyCharacter(this.PlayerSelectNumber);
        }

        public virtual IEnumerator PlayerPurchased(string id)
        {
            if (id.Contains("ch_sbm_"))
            {
                int Num = 0;
                string s = "";
                s = id.Replace("ch_sbm_", "");
                Num = int.Parse(s);
                this.PlayerSelectNumber = Num;
                this.SelectPlayer();
                this.RefreshPlayer();
                yield return new WaitForSeconds(0.3f);
                this.RefreshMaterial();
            }
        }

        public virtual void BuyCharacter(int type)
        {
            if (this.DataManager.GetBurgar() >= this.PlayersBuyPrice[type])
            {
                PlayerPrefs.SetInt("ch_sbm_" + type, 1);
                this.DataManager.TakeBurgar(this.PlayersBuyPrice[type]);
                this.StartCoroutine(this.PlayerPurchased("ch_sbm_" + type));
            }
            else
            {
                this.AudioManager.SendMessage("NoMoney");
                this.MenuManager.SendMessage("BurgerShopEnter");
            }
        }

        //----------------- Gift  -------------------
        public virtual void GiftShopEnter() // 0 = burgar ---- 1 = free gift
        {
            this.AudioManager.SendMessage("ButtonClick");
            this.GiftShopMenu.SetActive(true);
            if (this.CalculateGiftTime() == 0)
            {
                this.GiftBTN.SetActive(true);
                this.FreeGiftBTN.SetActive(false);
                this.GiftShopText.text = "GIFT AVAILABLE IN " + this.GiftTimeRemain();
            }
            else
            {
                this.FreeGiftBTN.SetActive(true);
                this.GiftBTN.SetActive(false);
                this.GiftShopText.text = "FREE DAILY GIFT";
            }
            this.BackBTN.SetActive(true);
            this.GiftShopAnimator.Play("GiftCome", -1, 0);
            this.BuyPlayerMenu = false;
        }

        public virtual int CalculateGiftTime()
        {
            string LT = PlayerPrefs.GetString("LastTimePlayed");
            System.DateTime Last = System.DateTime.Parse(LT);
            System.DateTime Current = System.DateTime.Now;
            System.TimeSpan Diff = Current.Subtract(Last).Duration();
            //print(Diff.TotalHours);	// Hours-Seconds-TotalHours-TotalSeconds-TotalDays
            if (PlayerPrefs.GetInt("CharacterGift") < 4)
            {
                if (PlayerPrefs.GetInt("CharacterGift") == 0)
                {
                    return 1; // Free Gift Time
                }
                if (PlayerPrefs.GetInt("CharacterGift") == 1)
                {
                    if (Diff.TotalMinutes > 2)
                    {
                        return 1; // Free Gift Time
                    }
                    else
                    {
                        return 0;
                    }
                }
                if (PlayerPrefs.GetInt("CharacterGift") == 2)
                {
                    if (Diff.TotalMinutes > 5)
                    {
                        return 1; // Free Gift Time
                    }
                    else
                    {
                        return 0;
                    }
                }
                if (PlayerPrefs.GetInt("CharacterGift") == 3)
                {
                    if (Diff.TotalMinutes > 15)
                    {
                        return 1; // Free Gift Time
                    }
                    else
                    {
                        return 0;
                    }
                }
            }
            else
            {
                if (Diff.TotalHours > 6)
                {
                    return 1; // Free Gift Time
                }
                else
                {
                    return 0;
                }
            }
            return 0;
        }

        public virtual string GiftTimeRemain()
        {
            string LT = PlayerPrefs.GetString("LastTimePlayed");
            System.DateTime Last = System.DateTime.Parse(LT);
            System.DateTime Current = System.DateTime.Now;
            System.TimeSpan Diff = Current.Subtract(Last).Duration();
            int hours = Mathf.FloorToInt((360 - Diff.Minutes) / 60f);
            int minutes = Mathf.FloorToInt((360 - Diff.Minutes) % 60f);
            //var seconds : int = Mathf.RoundToInt(Diff.TotalSeconds % 60f);
            string totime = (hours.ToString("00") + ":") + minutes.ToString("00");
            return totime;
        }

        public virtual void GiftShopExit()
        {
            this.AudioManager.SendMessage("ButtonClick");
            this.GiftShopAnimator.Play("GiftOut", -1, 0);
            this.StartCoroutine(this.GiftShopClose());
        }

        public virtual IEnumerator GiftShopClose()
        {
            yield return new WaitForSeconds(0.3f);
            this.GiftShopAnimator.Play("Idle", -1, 0);
            yield return new WaitForSeconds(0.1f);
            this.GiftShopMenu.SetActive(false);
        }

        public virtual void GetGift(int type) // 0 = burgar ---- 1 = free gift
        {
            this.AudioManager.SendMessage("GiftBTN");
            if (this.SlotMachinOn)
            {
                return;
            }
            if (type == 0)
            {
                if (this.DataManager.GetBurgar() >= 100)
                {
                    this.DataManager.TakeBurgar(100);
                    this.StartCoroutine(this.SlotMachin());
                }
                else
                {
                    this.MenuManager.SendMessage("BurgerShopEnter");
                }
            }
            if (type == 1)
            {
                PlayerPrefs.SetString("LastTimePlayed", System.DateTime.Now.ToString()); // Free Gift Time
                this.StartCoroutine(this.SlotMachin());
            }
        }

        public virtual IEnumerator SlotMachin()
        {
            this.SlotMachinOn = true;
            this.GiftBTN.SetActive(false);
            this.FreeGiftBTN.SetActive(false);
            this.BackBTN.SetActive(false);
            int[] ChNumbers = null;
            ChNumbers = new int[33];
            int ChAvalable = 0;
            int i = 1;
            while (i < 34)
            {
                if (PlayerPrefs.GetInt("ch_sbm_" + i) == 0)
                {
                    ChNumbers[ChAvalable] = i;
                    ChAvalable = ChAvalable + 1;
                }
                i++;
            }
            int ChTarget = Random.Range(0, ChAvalable);
            //print(ChNumbers[ChTarget]);
            int TargetPos = 0;
            switch (ChNumbers[ChTarget])
            {
                case 4:
                case 7:
                case 8:
                case 33:
                case 31:
                    TargetPos = 1;
                    break;
                case 13:
                case 24:
                case 25:
                case 26:
                    TargetPos = 2;
                    break;
                case 5:
                case 12:
                case 14:
                case 29:
                case 30:
                    TargetPos = 3;
                    break;
                case 1:
                case 2:
                case 9:
                case 15:
                    TargetPos = 4;
                    break;
                case 3:
                case 11:
                case 20:
                case 27:
                    TargetPos = 5;
                    break;
                case 16:
                case 17:
                case 18:
                    TargetPos = 6;
                    break;
                case 21:
                case 22:
                case 23:
                    TargetPos = 7;
                    break;
                case 6:
                case 10:
                case 19:
                case 28:
                case 32:
                    TargetPos = 8;
                    break;
                case 0:
                    TargetPos = 9;
                    break;
            }

            {
                int _65 = 0;
                Vector2 _66 = this.GiftNames.anchoredPosition;
                _66.y = _65;
                this.GiftNames.anchoredPosition = _66;
            }
            float pos = this.GiftNames.anchoredPosition.y;
            pos = pos + ((TargetPos + 20) * -42.67f);
            int SlotNum = 1;
            while (this.GiftNames.anchoredPosition.y > (pos + 2))
            {

                {
                    float _67 = Mathf.Lerp(this.GiftNames.anchoredPosition.y, pos, Time.deltaTime * 1.2f);
                    Vector2 _68 = this.GiftNames.anchoredPosition;
                    _68.y = _67;
                    this.GiftNames.anchoredPosition = _68;
                }
                //if(GiftNames.anchoredPosition.y % 30 > -2){AudioManager.SendMessage("SlotMachinMove");}
                if (this.GiftNames.anchoredPosition.y < (-42.67f * SlotNum))
                {
                    this.AudioManager.SendMessage("SlotMachinMove");
                    SlotNum = SlotNum + 1;
                }
                yield return null;
            }

            {
                float _69 = pos;
                Vector2 _70 = this.GiftNames.anchoredPosition;
                _70.y = _69;
                this.GiftNames.anchoredPosition = _70;
            }
            this.AudioManager.SendMessage("SlotMachinMove");
            yield return new WaitForSeconds(0.5f);
            if (ChNumbers[ChTarget] != 0)
            {
                this.CharacterIcon.sprite = this.CharacterTexture[ChNumbers[ChTarget] - 1];
                //StoreInventory.GiveItem(("ch_sbm_"+ChNumbers[ChTarget]),1);
                PlayerPrefs.SetInt("ch_sbm_" + ChNumbers[ChTarget], 1);
                this.PlayerSelectNumber = ChNumbers[ChTarget];
                this.SelectPlayer();
                this.RefreshPlayer();
                yield return new WaitForSeconds(0.3f);
                this.RefreshMaterial();
            }
            else
            {
                this.CharacterIcon.sprite = this.CharacterTexture[37];
                int FBN = Random.Range(0, 5);
                int FB = 0;
                switch (FBN)
                {
                    case 0:
                        FB = 2;
                        break;
                    case 1:
                        FB = 3;
                        break;
                    case 2:
                        FB = 4;
                        break;
                    case 3:
                        FB = 5;
                        break;
                    case 4:
                        FB = 2;
                        break;
                }
                this.BurgarGiftText.text = "" + FB;
                if (Random.Range(0, 2) == 0)
                {
                    this.CharacterIcon.sprite = this.CharacterTexture[38];
                    this.DataManager.SetData("TurboNumber", GameDataManager.GetData("TurboNumber") + FB);
                }
                else
                {
                    this.CharacterIcon.sprite = this.CharacterTexture[39];
                    this.DataManager.SetData("ShieldNumber", GameDataManager.GetData("ShieldNumber") + FB);
                }
            }
            this.AudioManager.SendMessage("WinCharacter");
            this.GiftShopAnimator.Play("Win", -1, 0);
            yield return new WaitForSeconds(0.8f);
            this.CharacterNameText.text = this.PlayersNames[ChNumbers[ChTarget]];
            yield return new WaitForSeconds(1.7f);
            this.GiftShopAnimator.Play("WinOut", -1, 0);

            {
                int _71 = 0;
                Vector2 _72 = this.CharacterRect.sizeDelta;
                _72.x = _71;
                this.CharacterRect.sizeDelta = _72;
            }

            {
                int _73 = 0;
                Vector2 _74 = this.CharacterRect.sizeDelta;
                _74.y = _73;
                this.CharacterRect.sizeDelta = _74;
            }

            {
                int _75 = 0;
                Vector2 _76 = this.GiftNames.anchoredPosition;
                _76.y = _75;
                this.GiftNames.anchoredPosition = _76;
            }
            this.SlotMachinOn = false;
            this.BurgarGiftText.text = "";
            this.CharacterNameText.text = "";
            this.ButtonAlarm.SetActive(false);
            this.MenuManager.SendMessage("ResetGiftButtons");
            PlayerPrefs.SetInt("CharacterGift", PlayerPrefs.GetInt("CharacterGift") + 1);
            PlayerPrefs.SetInt("GetGift", 1);
            this.StartCoroutine(this.GiftShopClose());
        }

        //---------------------- Buy -------------------------
        //----------------- ShowBurger -------------------
        public virtual void BuyDollar(int type)
        {
            GameObject cs = GameObject.Find("Purchaser");
            switch (type)
            {
                case 1:
                    cs.SendMessage("OnBuyProduct", 1);
                    break;
                case 2:
                    cs.SendMessage("OnBuyProduct", 2);
                    break;
                case 3:
                    cs.SendMessage("OnBuyProduct", 3);
                    break;
                case 4:
                    cs.SendMessage("OnBuyProduct", 4);
                    break;
                case 5:
                    cs.SendMessage("OnBuyProduct", 5);
                    break;
            }
        }
    }
}