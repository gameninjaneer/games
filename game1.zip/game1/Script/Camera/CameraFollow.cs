using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class CameraFollow : MonoBehaviour
    {
        public Transform target;
        public float smoothDampTime;
        public Vector3 cameraOffset;
        public float smoothYTime;
        private float YVelocity;
        private Vector3 _smoothDampVelocity;
        private float Zpos;
        private Camera Cam;
        private float TargetY;
        public virtual void Start()
        {
            this.Zpos = this.transform.position.z;
            this.Cam = this.GetComponent<Camera>();
        }

        public virtual void FixedUpdate()
        {
            if (!GameManager.Enable)
            {
                return;
            }
            if (this.target.position.y > 1f)
            {
                this.TargetY = 0f;
            }
            else
            {
                this.TargetY = -0.8f;
            }
            this.YVelocity = Mathf.Lerp(this.YVelocity, this.TargetY, Time.fixedDeltaTime * this.smoothYTime);
            this.transform.position = Vector3.SmoothDamp(this.transform.position, new Vector3(this.target.position.x, this.YVelocity, this.Zpos) - this.cameraOffset, ref this._smoothDampVelocity, this.smoothDampTime * Time.fixedDeltaTime);
            if (this.Cam.orthographicSize != 4.8f)
            {
                this.Cam.orthographicSize = Mathf.Lerp(this.Cam.orthographicSize, 4.7f, Time.fixedDeltaTime * 2f);
            }
        }

        public CameraFollow()
        {
            this.smoothDampTime = 0.2f;
            this.smoothYTime = 3f;
        }
    }
}