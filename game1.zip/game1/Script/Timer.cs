using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
namespace BMRolling
{
    public class Timer : MonoBehaviour
    {
        float timeRemaining = 120;
        public bool timerIsRunning = false;
        public Text timeText;
        public static Timer instance;
        public int SlowerCount;
        public GameManager GameManager;
        public int myinttimer;

        private void Start()
        {

            SlowerCount = 1;
            if (instance == null)
                instance = this;

        }

        void Update()
        {
            if (timerIsRunning)
            {
                if (timeRemaining > 0)
                {
                    timeRemaining -= Time.deltaTime;
                    DisplayTime(timeRemaining);
                    myinttimer = Mathf.RoundToInt(timeRemaining);
                }
                else
                {

                    timeRemaining = 0;
                    timerIsRunning = false;
                    print("LEVEL FAILED");
                    GameManager.instance.endgameTime();

                    //EndLevelObject.instance.levelComplete();


                }
            }


        }

        void DisplayTime(float timeToDisplay)
        {
            timeToDisplay += 1;
            float minutes = Mathf.FloorToInt(timeToDisplay / 60);
            float seconds = Mathf.FloorToInt(timeToDisplay % 60);
            timeText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
        }
    }
}