using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class PowerTrail : MonoBehaviour
    {
        public Transform _Player;
        public float smoothDampTime;
        private Vector3 smoothDampVelocity;
        public virtual void Update()
        {
            this.transform.position = Vector3.SmoothDamp(this.transform.position, new Vector3(this._Player.position.x, this._Player.position.y, 0.1f), ref this.smoothDampVelocity, this.smoothDampTime * Time.deltaTime);
        }

        public PowerTrail()
        {
            this.smoothDampTime = 0.2f;
        }
    }
}