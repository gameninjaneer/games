using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class UVScroller_xy : MonoBehaviour
    {
        public Vector2 scrollSpeed;
        public virtual void Update()
        {
            float offsetA = Time.time * this.scrollSpeed.x;
            float offsetB = Time.time * this.scrollSpeed.y;
            this.GetComponent<Renderer>().material.SetTextureOffset("_MainTex", new Vector2(offsetA / 2, offsetB));
        }
    }
}