using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class FxManager : MonoBehaviour
    {
        public GameObject BurgarFx;
        public GameObject BirdFx;
        public GameObject BubbleManDieFx;
        public GameObject CircleEffect;
        public GameObject TntFx;
        public GameObject BoxFx;
        public virtual void GetBurgarFx(Vector3 pos)
        {
            UnityEngine.Object.Instantiate(this.BurgarFx, pos, Quaternion.identity);
        }

        public virtual void Bird1Fx(Vector3 pos)
        {
            UnityEngine.Object.Instantiate(this.BirdFx, pos, Quaternion.identity);
        }

        public virtual void BubbleManDie(Vector3 pos)
        {
            UnityEngine.Object.Instantiate(this.BubbleManDieFx, pos, Quaternion.identity);
        }

        public virtual void CircleFx(Vector3 pos)
        {
            UnityEngine.Object.Instantiate(this.CircleEffect, pos, Quaternion.identity);
        }

        public virtual void BirdDieFx(Vector3 pos)
        {
            UnityEngine.Object.Instantiate(this.BirdFx, pos, Quaternion.identity);
        }

        public virtual void TNTExplod(Vector3 pos)
        {
            UnityEngine.Object.Instantiate(this.TntFx, pos, Quaternion.identity);
        }

        public virtual void Box(Vector3 pos)
        {
            UnityEngine.Object.Instantiate(this.BoxFx, pos, Quaternion.identity);
        }
    }
}