using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class UVScroller_Random : MonoBehaviour
    {
        public Vector2 scrollSpeed;
        public virtual void Update()
        {
            float offsetA = Time.time * Random.Range(-this.scrollSpeed.x, this.scrollSpeed.x);
            float offsetB = Time.time * Random.Range(-this.scrollSpeed.y, this.scrollSpeed.y);
            this.GetComponent<Renderer>().material.SetTextureOffset("_MainTex", new Vector2(offsetA / 2, offsetB));
        }
    }
}