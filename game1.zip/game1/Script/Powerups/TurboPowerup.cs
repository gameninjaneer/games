using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class TurboPowerup : MonoBehaviour
    {
        public virtual void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("Player"))
            {
                this.GetComponent<Collider2D>().enabled = false;
                GameObject.FindWithTag("Player").SendMessage("TurboStart", 1);
                UnityEngine.Object.Destroy(this.gameObject);
            }
        }
    }
}