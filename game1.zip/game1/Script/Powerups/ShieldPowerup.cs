using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class ShieldPowerup : MonoBehaviour
    {
        public virtual void OnTriggerEnter2D(Collider2D other)
        {
            if (other.CompareTag("Player"))
            {
                this.GetComponent<Collider2D>().enabled = false;
                //GameObject.FindWithTag("Player").SendMessage("cfdsq`2deswaq0", 1);
                UnityEngine.Object.Destroy(this.gameObject);
            }
        }

    }
}