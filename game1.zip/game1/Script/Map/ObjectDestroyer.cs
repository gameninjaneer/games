using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class ObjectDestroyer : MonoBehaviour
    {
        public int Dist;
        private Transform _Player;
        public virtual void Start()
        {
            this.InvokeRepeating("Check", 2f, 2f);
            this._Player = GameObject.FindWithTag("Player").transform;
        }

        public virtual void Check()
        {
            if ((this._Player.position.x - this.transform.position.x) > this.Dist)
            {
                UnityEngine.Object.Destroy(this.gameObject);
            }
        }

        public ObjectDestroyer()
        {
            this.Dist = 30;
        }
    }
}