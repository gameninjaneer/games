using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
public class StageObjects : object
{
    public string StageName;
    public GameObject[] StagePrefabs;
    public StageObjects()
    {
        this.StageName = "";
    }

}
    [System.Serializable]
    public partial class MapGenerator : MonoBehaviour
    {
        public GameObject[] StageEmpty;
        public float BlockSpacing;
        public GameObject[] Birds;
        public Transform Player;
        public StageObjects[] FirstStage;
        public StageObjects[] Stages;
        public GameObject TractorStage;
        public GameObject PreTurboStage;
        public GameObject[] TurboStage;
        public GameObject SkyChangeStage;
        public GameObject[] CloudBackUp;
        public GameObject[] CloudBackDown;
        public GameObject[] Lights;
        public GameObject[] LightsDisco;
        public SpriteRenderer[] Sky;
        public UnityEngine.UI.Image FlashUI;
        public Material CluodMaterial;
        public GameObject _ModeManager;
        private int GeneratePos;
        private float PosY;
        private int FirstStageSelect;
        private float BirdTime;
        private int TractorTime;
        private bool Tractor;
        private float TurboTime;
        private bool Turbo;
        private float SkyCahngeTime;
        private bool SC;
        private bool GetTurbo;
        private int SkyNumber;
        public virtual IEnumerator Start()
        {
            if (PlayerPrefs.GetInt("GamePlayed") > 0)
            {
                this.SkyNumber = Random.Range(0, 3) - 1;
                this.StartCoroutine(this.SkyChange());
            }
            this.GenerateEmpty();
            while (!GameManager.Enable)
            {
                yield return null;
            }
            this.TractorTime = (int)(Time.time + 120);
            this.TurboTime = Time.time + 65;
            this.SkyCahngeTime = Time.time + 90;
        }

        public virtual void Generate()
        {
            if (Time.time > this.TractorTime)
            {
                this.Tractor = true;
            }
            if (Time.time > this.TurboTime)
            {
                this.Turbo = true;
            }
            if (Time.time > this.SkyCahngeTime)
            {
                this.SC = true;
            }
            this.GeneratePos = (int)(this.GeneratePos + this.BlockSpacing);
            if (!GameManager.Enable)
            {
                UnityEngine.Object.Instantiate(this.StageEmpty[Random.Range(0, this.StageEmpty.Length)], new Vector3(this.GeneratePos, this.PosY, 2), Quaternion.identity);
            }
            else
            {
                if (this.GetTurbo)
                {
                    UnityEngine.Object.Instantiate(this.TurboStage[Random.Range(0, this.TurboStage.Length)], new Vector3(this.GeneratePos, this.PosY, 2), Quaternion.identity);
                    this.GeneratePos = (int)(this.GeneratePos + this.BlockSpacing);
                    this.GetTurbo = false;
                    return;
                }
                if (GameManager.Stage == 0)
                {
                    UnityEngine.Object.Instantiate(this.FirstStage[this.FirstStageSelect].StagePrefabs[Random.Range(0, this.FirstStage[this.FirstStageSelect].StagePrefabs.Length)], new Vector3(this.GeneratePos, this.PosY, 2), Quaternion.identity);
                    this.FirstStageSelect = this.FirstStageSelect + 1;
                }
                else
                {
                    if ((!this.Tractor && !this.Turbo) && !this.SC)
                    {
                        UnityEngine.Object.Instantiate(this.Stages[GameManager.Stage - 1].StagePrefabs[Random.Range(0, this.Stages[GameManager.Stage - 1].StagePrefabs.Length)], new Vector3(this.GeneratePos, this.PosY, 2), Quaternion.identity);
                    }
                    else
                    {
                        if (this.SC)
                        {
                            UnityEngine.Object.Instantiate(this.SkyChangeStage, new Vector3(this.GeneratePos, this.PosY, 2), Quaternion.identity);
                            this.SC = false;
                            this.SkyCahngeTime = this.SkyCahngeTime + 90;
                        }
                        else
                        {
                            if (this.Tractor)
                            {
                                UnityEngine.Object.Instantiate(this.TractorStage, new Vector3(this.GeneratePos, this.PosY, 2), Quaternion.identity);
                                this.GeneratePos = (int)(this.GeneratePos + this.BlockSpacing);
                                this.Tractor = false;
                                this.TractorTime = this.TractorTime + 100;
                            }
                            else
                            {
                                if (this.Turbo)
                                {
                                    UnityEngine.Object.Instantiate(this.PreTurboStage, new Vector3(this.GeneratePos, this.PosY, 2), Quaternion.identity);
                                    this.Turbo = false;
                                    this.TurboTime = this.TurboTime + 80;
                                }
                            }
                        }
                    }
                }
                UnityEngine.Object.Instantiate(this.CloudBackUp[Random.Range(0, 4)], new Vector3(this.GeneratePos, Random.Range(4.5f, 5.8f), 19), Quaternion.identity);
                UnityEngine.Object.Instantiate(this.CloudBackDown[Random.Range(0, 5)], new Vector3(this.GeneratePos, Random.Range(-3.55f, -4.9f), 19), Quaternion.identity);
                if ((((ModeManager.Style != 6) && (ModeManager.Style != 7)) && (ModeManager.Style != 8)) && (ModeManager.Style != 12))
                {
                    if ((ModeManager.Style == 10) || (ModeManager.Style == 11))
                    {
                        UnityEngine.Object.Instantiate(this.LightsDisco[Random.Range(0, 4)], new Vector3(this.GeneratePos, Random.Range(4.7f, 5f), -5), Quaternion.identity);
                    }
                    else
                    {
                        if (GameManager.Night)
                        {
                            UnityEngine.Object.Instantiate(this.Lights[Random.Range(0, 5)], new Vector3(this.GeneratePos, Random.Range(4.7f, 5f), -5), Quaternion.identity);
                        }
                    }
                }
            }
        }

        public virtual void GenerateEmpty()
        {
            this.GeneratePos = (int)(this.GeneratePos + this.BlockSpacing);
            UnityEngine.Object.Instantiate(this.StageEmpty[Random.Range(0, this.StageEmpty.Length)], new Vector3(this.GeneratePos, this.PosY, 2), Quaternion.identity);
        }

        public virtual void SetJet()
        {
            this.GetTurbo = true;
        }

        public virtual IEnumerator SkyChange()
        {
            yield return null;
            this.SkyNumber = this.SkyNumber + 1;
            if (this.SkyNumber == 1)
            {
                if ((ModeManager.Style == 1) || (ModeManager.Style == 2))
                {
                    this.SkyNumber = this.SkyNumber + 1;
                }
            }
            if (this.SkyNumber > 2)
            {
                this.SkyNumber = 0;
            }
            this.FlashUI.enabled = true;

            {
                float _77 = 0.65f;
                Color _78 = this.FlashUI.color;
                _78.a = _77;
                this.FlashUI.color = _78;
            }
            if (this.SkyNumber == 0)
            {
                GameManager.Night = false;
                GameManager.Noon = false;
                this.CluodMaterial.color = new Color(1, 1, 1, 0.55f);
                this._ModeManager.SendMessage("SetCluodColor");
                while (this.Sky[0].color.a < 0.95f)
                {

                    {
                        float _79 = Mathf.Lerp(this.Sky[0].color.a, 1f, Time.deltaTime * 6f);
                        Color _80 = this.Sky[0].color;
                        _80.a = _79;
                        this.Sky[0].color = _80;
                    }

                    {
                        float _81 = this.FlashUI.color.a - 0.08f;
                        Color _82 = this.FlashUI.color;
                        _82.a = _81;
                        this.FlashUI.color = _82;
                    }
                    yield return null;
                }

                {
                    int _83 = 1;
                    Color _84 = this.Sky[0].color;
                    _84.a = _83;
                    this.Sky[0].color = _84;
                }
            }
            if (this.SkyNumber == 1)
            {
                GameManager.Noon = true;
                this.CluodMaterial.color = new Color(1, 1, 1, 0.25f);
                this._ModeManager.SendMessage("SetCluodColor");

                {
                    int _85 = 1;
                    Color _86 = this.Sky[1].color;
                    _86.a = _85;
                    this.Sky[1].color = _86;
                }
                while (this.Sky[0].color.a > 0.05f)
                {

                    {
                        float _87 = Mathf.Lerp(this.Sky[0].color.a, 0f, Time.deltaTime * 6f);
                        Color _88 = this.Sky[0].color;
                        _88.a = _87;
                        this.Sky[0].color = _88;
                    }

                    {
                        float _89 = this.FlashUI.color.a - 0.08f;
                        Color _90 = this.FlashUI.color;
                        _90.a = _89;
                        this.FlashUI.color = _90;
                    }
                    yield return null;
                }

                {
                    int _91 = 0;
                    Color _92 = this.Sky[0].color;
                    _92.a = _91;
                    this.Sky[0].color = _92;
                }
            }
            if (this.SkyNumber == 2)
            {
                GameManager.Night = true;
                GameManager.Noon = false;
                this.CluodMaterial.color = new Color(1, 1, 1, 0.15f);
                this._ModeManager.SendMessage("SetCluodColor");

                {
                    int _93 = 1;
                    Color _94 = this.Sky[2].color;
                    _94.a = _93;
                    this.Sky[2].color = _94;
                }
                while (this.Sky[1].color.a > 0.05f)
                {

                    {
                        float _95 = Mathf.Lerp(this.Sky[1].color.a, 0f, Time.deltaTime * 6f);
                        Color _96 = this.Sky[0].color;
                        _96.a = _95;
                        this.Sky[0].color = _96;
                    }

                    {
                        float _97 = Mathf.Lerp(this.Sky[1].color.a, 0f, Time.deltaTime * 6f);
                        Color _98 = this.Sky[1].color;
                        _98.a = _97;
                        this.Sky[1].color = _98;
                    }

                    {
                        float _99 = this.FlashUI.color.a - 0.08f;
                        Color _100 = this.FlashUI.color;
                        _100.a = _99;
                        this.FlashUI.color = _100;
                    }
                    yield return null;
                }

                {
                    int _101 = 0;
                    Color _102 = this.Sky[0].color;
                    _102.a = _101;
                    this.Sky[0].color = _102;
                }

                {
                    int _103 = 0;
                    Color _104 = this.Sky[1].color;
                    _104.a = _103;
                    this.Sky[1].color = _104;
                }
            }

            {
                float _105 = 0f;
                Color _106 = this.FlashUI.color;
                _106.a = _105;
                this.FlashUI.color = _106;
            }
            this.FlashUI.enabled = false;
        }

        public MapGenerator()
        {
            this.BlockSpacing = 20f;
            this.GeneratePos = -30;
            this.PosY = -5f;
            this.BirdTime = 10f;
            this.TractorTime = 123;
        }
    }
}