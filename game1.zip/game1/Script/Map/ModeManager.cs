using UnityEngine;
using System.Collections;

namespace BMRolling
{
    [System.Serializable]
    public partial class ModeManager : MonoBehaviour
    {
        public GameObject[] Filters;
        public GameObject[] Particles;
        public GameObject CastomSky;
        public GameObject CastomSky2;
        public Sprite[] SkyTextures;
        public Material[] HouseMaterial;
        public Texture2D[] HouseTextures1;
        public Texture2D[] HouseTextures2;
        public Texture2D[] HouseTextures3;
        public Texture2D[] HouseTextures4;
        public Material HouseBackMaterial;
        public Texture2D[] HouseBackTextures;
        public Material CluodMaterial;
        public static int Style;
        private SpriteRenderer CastomSkyTexture;
        //0 normal	(0)
        //1 Crismas	(2-25)
        //2 snowy	(5-18)
        //3 rainy	(16-29-33)
        //4 fogy	(14-35)
        //5 Toxic	()
        //6 Desert	(9-22-24-30)
        //7 Goest	(10-19-28-34-36)
        //8 Space	(11-20-27)
        //9 Old		(4-8)
        //10 naked	(3-12)
        //11 Disco	(1-15)
        //12 Hell	(26-32-37)
        public virtual void Start()
        {

            this.CastomSkyTexture = this.CastomSky.GetComponent<SpriteRenderer>();
            ModeManager.Style = 0;
            this.SetMode();
            //kamran start Mode
        }

        public virtual void SetMode()
        {
            print("setmode");
            this.RestartMode();
            ModeManager.Style = 0;
            this.HouseMaterial[0].mainTexture = this.HouseTextures1[0];
            this.HouseMaterial[1].mainTexture = this.HouseTextures2[0];
            this.HouseMaterial[2].mainTexture = this.HouseTextures3[0];
            this.HouseMaterial[3].mainTexture = this.HouseTextures4[0];
            this.HouseBackMaterial.mainTexture = this.HouseBackTextures[0];
            int index = Random.Range(1, 35);
            print(index);
            switch (index)
            {
                case 0:
                    ModeManager.Style = 0;

                    break;
                case 2:
                case 25:
                    ModeManager.Style = 1;
                    this.Particles[0].SetActive(true);
                    this.HouseMaterial[0].mainTexture = this.HouseTextures1[5];
                    this.HouseMaterial[1].mainTexture = this.HouseTextures2[5];
                    this.HouseMaterial[2].mainTexture = this.HouseTextures3[5];
                    this.HouseMaterial[3].mainTexture = this.HouseTextures4[5];
                    this.HouseBackMaterial.mainTexture = this.HouseBackTextures[6];
                    break;
                case 5:
                case 18:
                    ModeManager.Style = 2;
                    this.Particles[0].SetActive(true);
                    this.HouseMaterial[0].mainTexture = this.HouseTextures1[5];
                    this.HouseMaterial[1].mainTexture = this.HouseTextures2[5];
                    this.HouseMaterial[2].mainTexture = this.HouseTextures3[5];
                    this.HouseMaterial[3].mainTexture = this.HouseTextures4[5];
                    this.HouseBackMaterial.mainTexture = this.HouseBackTextures[7];
                    break;
                case 16:
                case 29:
                case 33:
                    ModeManager.Style = 3;
                    this.Particles[1].SetActive(true);
                    this.Filters[2].SetActive(true);
                    this.HouseBackMaterial.mainTexture = this.HouseBackTextures[5];
                    break;
                case 14:
                case 35:
                    ModeManager.Style = 4;
                    this.Filters[3].SetActive(true);
                    this.CastomSky.SetActive(true);
                    this.CastomSkyTexture.sprite = this.SkyTextures[4];
                    this.HouseBackMaterial.mainTexture = this.HouseBackTextures[5];
                    break;
                case 9:
                case 22:
                case 24:
                case 30:
                    ModeManager.Style = 6;
                    this.CastomSky.SetActive(true);
                    this.CastomSkyTexture.sprite = this.SkyTextures[0];
                    this.HouseMaterial[0].mainTexture = this.HouseTextures1[1];
                    this.HouseMaterial[1].mainTexture = this.HouseTextures2[1];
                    this.HouseMaterial[2].mainTexture = this.HouseTextures3[1];
                    this.HouseMaterial[3].mainTexture = this.HouseTextures4[1];
                    this.HouseBackMaterial.mainTexture = this.HouseBackTextures[1];
                    break;
                case 10:
                case 19:
                case 28:
                case 34:
                case 36:
                    ModeManager.Style = 7;
                    this.CastomSky.SetActive(true);
                    this.Particles[3].SetActive(true);

                    this.CastomSkyTexture.sprite = this.SkyTextures[1];
                    this.HouseMaterial[0].mainTexture = this.HouseTextures1[2];
                    this.HouseMaterial[1].mainTexture = this.HouseTextures2[2];
                    this.HouseMaterial[2].mainTexture = this.HouseTextures3[2];
                    this.HouseMaterial[3].mainTexture = this.HouseTextures4[2];
                    this.HouseBackMaterial.mainTexture = this.HouseBackTextures[2];
                    break;
                case 11:
                case 20:
                case 27:
                    ModeManager.Style = 8;
                    this.CastomSky.SetActive(true);
                    this.CastomSkyTexture.sprite = this.SkyTextures[2];
                    this.HouseMaterial[0].mainTexture = this.HouseTextures1[4];
                    this.HouseMaterial[1].mainTexture = this.HouseTextures2[4];
                    this.HouseMaterial[2].mainTexture = this.HouseTextures3[4];
                    this.HouseMaterial[3].mainTexture = this.HouseTextures4[4];
                    this.HouseBackMaterial.mainTexture = this.HouseBackTextures[4];
                    break;
                case 4:
                case 8:
                    ModeManager.Style = 9;
                    this.Filters[1].SetActive(true);
                    break;
                case 3:
                    ModeManager.Style = 10;
                    this.CastomSky2.SetActive(true);
                    this.HouseBackMaterial.mainTexture = this.HouseBackTextures[8];
                    break;
                case 1:
                case 15:
                    ModeManager.Style = 11;
                    this.Particles[2].SetActive(true);
                    this.CastomSky2.SetActive(true);
                    this.HouseBackMaterial.mainTexture = this.HouseBackTextures[8];
                    break;
                case 26:
                case 32:
                case 37:
                    ModeManager.Style = 12;
                    this.CastomSky.SetActive(true);
                    this.CastomSkyTexture.sprite = this.SkyTextures[3];
                    this.HouseMaterial[0].mainTexture = this.HouseTextures1[3];
                    this.HouseMaterial[1].mainTexture = this.HouseTextures2[3];
                    this.HouseMaterial[2].mainTexture = this.HouseTextures3[3];
                    this.HouseMaterial[3].mainTexture = this.HouseTextures4[3];
                    this.HouseBackMaterial.mainTexture = this.HouseBackTextures[3];
                    break;
            }
            this.SetCluodColor();
        }

        public virtual void SetCluodColor()
        {
            if (ModeManager.Style == 6) //Desert
            {
                this.CluodMaterial.color = new Color(1, 1, 1, 0.4f);
                return;
            }
            if (ModeManager.Style == 7) //Ghost
            {
                //S.color = Color(0,1,0.6,0.25);
                this.CluodMaterial.color = new Color(0, 1, 0.6f, 0.25f);
                return;
            }
            if (ModeManager.Style == 8) //Space
            {
                //S.color = Color(0.17,0.29,1,0.25);
                this.CluodMaterial.color = new Color(0.17f, 0.29f, 1, 0.15f);
                return;
            }
            if (ModeManager.Style == 12) //Hell
            {
                //S.color = Color(0,0,0,0.2);
                this.CluodMaterial.color = new Color(0, 0, 0, 0.2f);
                return;
            }
            if (((ModeManager.Style == 4) || (ModeManager.Style == 10)) || (ModeManager.Style == 11)) //Disco
            {
                this.CluodMaterial.color = new Color(0.5f, 0.5f, 1, 0.1f);
                return;
            }
            // Normal
            if (GameManager.Night) //night
            {
                //S.color.a = 0.15;
                this.CluodMaterial.color = new Color(1, 1, 1, 0.15f);
                if ((((((ModeManager.Style != 1) && (ModeManager.Style != 2)) && (ModeManager.Style != 3)) && (ModeManager.Style != 4)) && (ModeManager.Style != 10)) && (ModeManager.Style != 11))
                {
                    this.HouseBackMaterial.mainTexture = this.HouseBackTextures[5];
                }
            }
            else
            {
                //day
                //S.color.a = 0.55;
                if (GameManager.Noon)
                {
                    this.CluodMaterial.color = new Color(1, 1, 1, 0.25f);
                }
                else
                {
                    this.CluodMaterial.color = new Color(1, 1, 1, 0.55f);
                }
                if ((((((ModeManager.Style != 1) && (ModeManager.Style != 2)) && (ModeManager.Style != 3)) && (ModeManager.Style != 4)) && (ModeManager.Style != 10)) && (ModeManager.Style != 11))
                {
                    this.HouseBackMaterial.mainTexture = this.HouseBackTextures[0];
                }
            }
        }

        public virtual void RestartMode()
        {
            this.CastomSky.SetActive(false);
            this.CastomSky2.SetActive(false);
            int i = 0;
            while (i < this.Filters.Length)
            {
                this.Filters[i].SetActive(false);
                i++;
            }
            int j = 0;
            while (j < this.Particles.Length)
            {
                this.Particles[j].SetActive(false);
                j++;
            }
        }
    }
}